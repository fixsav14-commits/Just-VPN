package com.vpnbest.app

import android.content.Context
import android.util.Base64
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import java.util.concurrent.TimeUnit

/** Итог скачивания: готовый текст списка (с пометками групп) и сводка для журнала. */
class Downloaded(
    val lines: List<String>,
    val files: Int,
    val total: Int,
    val linkCount: Int,
    val mirror: String,
)

/**
 * Список серверов. Встроенный лежит в assets/servers.txt, но бесплатные списки меняются каждый час,
 * поэтому приложение умеет скачивать свежие (репозиторий igareck/vpn-configs-for-russia и его зеркала)
 * и хранит их в своей папке. Свои ссылки (из буфера обмена) лежат отдельно и добавляются сверху.
 */
object ListStore {

    private class Source(val group: String, val file: String)

    // порядок важен: если сервер есть в нескольких списках, он остаётся в первом
    private val SOURCES = listOf(
        Source("CIDR", "WHITE-CIDR-RU-all.txt"),
        Source("CIDR", "Vless-Reality-White-Lists-Rus-Mobile.txt"),
        Source("CIDR", "WHITE-CIDR-RU-checked.txt"),
        Source("SNI", "WHITE-SNI-RU-all.txt"),
        Source("BL", "BLACK_VLESS_RUS_mobile.txt"),
        Source("BL", "BLACK_VLESS_RUS.txt"),
        Source("BL", "BLACK_SS+All_RUS.txt"),
        Source("BL", "BLACK_SS_WEAK_DPI_RUS.txt"),
    )

    // первым идёт оригинал, дальше зеркала на случай, если GitHub у провайдера закрыт
    private val MIRRORS = listOf(
        "https://raw.githubusercontent.com/igareck/vpn-configs-for-russia/refs/heads/main/",
        "https://raw.githack.com/igareck/vpn-configs-for-russia/main/",
        "https://gitlab.com/igareck/vpn-configs-for-russia/-/raw/main/",
        "https://codeberg.org/igareck/vpn-configs-for-russia/raw/branch/main/",
        "https://bitbucket.org/igareck/vpn-configs-for-russia/raw/main/",
        "https://gitea.com/igareck/vpn-configs-for-russia/raw/branch/main/",
        "https://cdn.jsdelivr.net/gh/igareck/vpn-configs-for-russia@main/", // кэш до 12 часов, поэтому последний
    )

    private val SCHEMES = listOf("vless", "vmess", "trojan", "hysteria2", "hy2", "ss")

    private val daemon = ThreadFactory { r -> Thread(r).apply { isDaemon = true } }

    // ---------- хранение ----------

    private fun listFile(c: Context) = File(c.filesDir, "servers.txt")
    private fun customFile(c: Context) = File(c.filesDir, "custom.txt")

    /** Строки для разбора: скачанный список (или встроенный) и свои ссылки. */
    fun load(c: Context): List<String> {
        val out = ArrayList<String>()
        val f = listFile(c)
        val own = try {
            if (f.exists() && f.length() > 0) f.readLines() else null
        } catch (_: Throwable) {
            null
        }
        out.addAll(own ?: c.assets.open("servers.txt").bufferedReader().use { it.readLines() })
        val cf = customFile(c)
        if (cf.exists()) {
            out.add("#group") // свои ссылки не относятся ни к BL, ни к CIDR
            try {
                out.addAll(cf.readLines())
            } catch (_: Throwable) {
            }
        }
        return out
    }

    fun save(c: Context, lines: List<String>) {
        val tmp = File(c.filesDir, "servers.txt.tmp")
        tmp.writeText(lines.joinToString("\n") + "\n")
        val f = listFile(c)
        if (!tmp.renameTo(f)) {
            f.writeText(tmp.readText())
            tmp.delete()
        }
    }

    /** Добавляет свои ссылки; возвращает, сколько из них новых. */
    fun addCustom(c: Context, links: List<String>): Int {
        val cf = customFile(c)
        val have = LinkedHashSet<String>()
        if (cf.exists()) have.addAll(cf.readLines().map { it.trim() }.filter { it.isNotEmpty() })
        val before = have.size
        have.addAll(links.map { it.trim() })
        cf.writeText(have.joinToString("\n") + "\n")
        return have.size - before
    }

    /** Возвращает встроенный список и удаляет скачанное и добавленное вручную. */
    fun reset(c: Context) {
        listFile(c).delete()
        customFile(c).delete()
    }

    fun hasCustom(c: Context): Boolean = customFile(c).let { it.exists() && it.length() > 0 }

    // ---------- разбор текста ----------

    private fun linksIn(text: String): List<String> =
        text.lineSequence()
            .map { it.trim() }
            .filter { l ->
                l.isNotEmpty() && !l.startsWith("#") && SCHEMES.any { l.startsWith("$it://", ignoreCase = true) }
            }
            .toList()

    /** Ссылки из текста: обычные строки или подписка, закодированная в base64. */
    fun extractLinks(text: String): List<String> {
        val plain = linksIn(text)
        if (plain.isNotEmpty()) return plain
        return try {
            var t = text.trim().filter { !it.isWhitespace() }.replace('-', '+').replace('_', '/')
            if (t.length < 16 || t.contains("://")) return emptyList()
            while (t.length % 4 != 0) t += "="
            linksIn(String(Base64.decode(t, Base64.DEFAULT), Charsets.UTF_8))
        } catch (_: Throwable) {
            emptyList()
        }
    }

    // ---------- скачивание ----------

    private fun encodePath(p: String) = p.replace("+", "%2B")

    /** Одна страница по адресу; через локальный вход ядра, если указан порт (когда VPN уже включён). */
    fun fetch(url: String, proxyPort: Int?): String {
        val c = if (proxyPort != null) {
            URL(url).openConnection(Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", proxyPort)))
        } else {
            URL(url).openConnection()
        } as HttpURLConnection
        try {
            c.connectTimeout = 5000
            c.readTimeout = 9000
            c.useCaches = false
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) VpnBest")
            val code = c.responseCode
            if (code != 200) throw java.io.IOException("HTTP $code")
            val buf = java.io.ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val b = ByteArray(16384)
                while (true) {
                    val n = ins.read(b)
                    if (n < 0) break
                    buf.write(b, 0, n)
                    if (buf.size() > 4_000_000) throw java.io.IOException("слишком большой ответ")
                }
            }
            return buf.toString("UTF-8")
        } finally {
            c.disconnect()
        }
    }

    /** Скачивает все файлы списка, для каждого перебирает зеркала. null — не получилось ничего. */
    fun download(proxyPort: Int?, log: (String) -> Unit, mirrors: List<String> = MIRRORS): Downloaded? {
        // если VPN уже включён, но через него не идёт интернет, пробуем ещё и напрямую
        val attempts = if (proxyPort != null) listOf(proxyPort, null) else listOf(null)
        for (p in attempts) {
            val r = downloadOnce(p, log, mirrors)
            if (r != null) return r
        }
        return null
    }

    private fun downloadOnce(proxyPort: Int?, log: (String) -> Unit, mirrors: List<String>): Downloaded? {
        log("Скачиваю свежие списки (" + (if (proxyPort != null) "через включённый VPN" else "напрямую") + ")…")
        val dead = ConcurrentHashMap.newKeySet<Int>() // зеркала, до которых не достучаться
        val results = arrayOfNulls<List<String>>(SOURCES.size)
        val usedMirror = IntArray(SOURCES.size) { -1 }
        val pool = Executors.newFixedThreadPool(SOURCES.size, daemon)
        val latch = CountDownLatch(SOURCES.size)
        for ((i, src) in SOURCES.withIndex()) {
            pool.execute {
                try {
                    for ((mi, base) in mirrors.withIndex()) {
                        if (dead.contains(mi)) continue
                        try {
                            val text = fetch(base + encodePath(src.file), proxyPort)
                            val links = extractLinks(text)
                            // пустой, но настоящий файл списка («Количество: 0») — не ошибка: так и задумано,
                            // и брать вместо него устаревшую копию с другого зеркала не нужно
                            if (links.isEmpty() && !text.contains("profile-title") && !text.contains("Количество")) {
                                throw java.io.IOException("нет ссылок в ответе")
                            }
                            results[i] = links
                            usedMirror[i] = mi
                            if (links.isEmpty()) log("  ${src.file}: в источнике сейчас пусто (серверов 0)")
                            break
                        } catch (e: Throwable) {
                            val host = URL(base).host
                            val http = (e.message ?: "").startsWith("HTTP ")
                            if (!http && e !is java.io.FileNotFoundException) {
                                // зеркало не отвечает совсем: другим файлам его пробовать незачем
                                if (e is java.net.SocketTimeoutException || e is java.net.UnknownHostException ||
                                    e is java.net.ConnectException || e is javax.net.ssl.SSLException
                                ) dead.add(mi)
                            }
                            log("  ${src.file}: $host — ${e.javaClass.simpleName}: ${(e.message ?: "").take(60)}")
                        }
                    }
                } finally {
                    latch.countDown()
                }
            }
        }
        latch.await(35, TimeUnit.SECONDS)
        pool.shutdownNow()

        val lines = ArrayList<String>()
        var files = 0
        var links = 0
        val mirrorsUsed = HashSet<String>()
        for ((i, src) in SOURCES.withIndex()) {
            val l = results[i] ?: continue
            files++
            links += l.size
            lines.add("#group ${src.group}")
            lines.addAll(l)
            mirrorsUsed.add(URL(mirrors[usedMirror[i]]).host)
        }
        if (files == 0) {
            log("Свежие списки скачать не удалось")
            return null
        }
        log("Скачано файлов: $files из ${SOURCES.size}, ссылок: $links (${mirrorsUsed.joinToString(", ")})")
        if (mirrorsUsed.contains("cdn.jsdelivr.net")) {
            log("Внимание: часть файлов взята у jsDelivr, он хранит копии до 12 часов, такие серверы могут быть мёртвыми")
        }
        return Downloaded(lines, files, SOURCES.size, links, mirrorsUsed.joinToString(", "))
    }
}
