package com.vpnbest.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import android.util.Log
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.SetupOptions
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import java.net.NetworkInterface as JNetworkInterface
import io.nekohasekai.libbox.NetworkInterface as BoxNetworkInterface
import io.nekohasekai.libbox.Notification as BoxNotification

/** Состояние VPN, которое читает экран. */
object VpnState {
    @Volatile var running = false
    @Volatile var connecting = false
    @Volatile var lastError: String? = null
    @Volatile var listener: (() -> Unit)? = null

    fun update(running: Boolean, connecting: Boolean, error: String? = null) {
        this.running = running
        this.connecting = connecting
        this.lastError = error
        Handler(Looper.getMainLooper()).post { listener?.invoke() }
    }
}

class BoxVpnService : VpnService(), PlatformInterface {

    private var box: BoxService? = null
    private var tun: ParcelFileDescriptor? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopAll()
            ACTION_START -> {
                val cfg = intent.getStringExtra(EXTRA_CONFIG)
                if (cfg == null) {
                    stopAll()
                } else {
                    startForegroundNotification()
                    Thread { startBox(cfg) }.start()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "vpn") else Notification.Builder(this)
        val n = b.setContentTitle("VPN Best")
            .setContentText("VPN работает")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
        startForeground(1, n)
    }

    @Synchronized
    private fun startBox(config: String) {
        try {
            closeBox()
            val opts = SetupOptions()
            opts.basePath = filesDir.path
            opts.workingPath = filesDir.path
            opts.tempPath = cacheDir.path
            Libbox.setup(opts)
            CrashLog.redirectGoStderr(this)
            val svc = Libbox.newService(config, this)
            svc.start()
            box = svc
            VpnState.update(running = true, connecting = false)
        } catch (e: Throwable) {
            Log.e(TAG, "start failed", e)
            VpnState.update(running = false, connecting = false, error = e.message ?: e.toString())
            closeBox()
            stopForegroundCompat()
            stopSelf()
        }
    }

    @Synchronized
    private fun closeBox() {
        try {
            box?.close()
        } catch (e: Throwable) {
            Log.w(TAG, "close", e)
        }
        box = null
        try {
            tun?.close()
        } catch (_: Throwable) {
        }
        tun = null
    }

    private fun stopAll() {
        Thread {
            closeBox()
            VpnState.update(running = false, connecting = false)
            stopForegroundCompat()
            stopSelf()
        }.start()
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
    }

    override fun onRevoke() {
        stopAll()
    }

    override fun onDestroy() {
        closeBox()
        VpnState.update(running = false, connecting = false)
        super.onDestroy()
    }

    // ---------- PlatformInterface ----------

    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

    override fun autoDetectInterfaceControl(fd: Int) {
        protect(fd)
    }

    override fun openTun(options: TunOptions): Int {
        val b = Builder()
            .setSession("VPN Best")
            .setMtu(options.mtu)

        val a4 = options.inet4Address
        while (a4.hasNext()) {
            val p = a4.next()
            b.addAddress(p.address(), p.prefix())
        }
        val a6 = options.inet6Address
        while (a6.hasNext()) {
            val p = a6.next()
            b.addAddress(p.address(), p.prefix())
        }

        if (options.autoRoute) {
            b.addDnsServer(options.dnsServerAddress.value)
            val r4 = options.inet4RouteAddress
            if (r4.hasNext()) {
                while (r4.hasNext()) {
                    val p = r4.next()
                    b.addRoute(p.address(), p.prefix())
                }
            } else {
                b.addRoute("0.0.0.0", 0)
            }
            val r6 = options.inet6RouteAddress
            if (r6.hasNext()) {
                while (r6.hasNext()) {
                    val p = r6.next()
                    b.addRoute(p.address(), p.prefix())
                }
            } else {
                b.addRoute("::", 0)
            }
        }

        // само приложение идёт мимо туннеля: так замер пинга всегда показывает реальную сеть
        try {
            b.addDisallowedApplication(packageName)
        } catch (_: Exception) {
        }

        val pfd = b.establish() ?: throw IllegalStateException("не удалось создать VPN-интерфейс")
        tun = pfd
        return pfd.fd
    }

    override fun writeLog(message: String) {
        Log.i(TAG, message)
    }

    override fun useProcFS(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

    override fun findConnectionOwner(
        ipProtocol: Int,
        sourceAddress: String,
        sourcePort: Int,
        destinationAddress: String,
        destinationPort: Int,
    ): Int = throw UnsupportedOperationException("не поддерживается")

    override fun packageNameByUid(uid: Int): String = throw UnsupportedOperationException("не поддерживается")

    override fun uidByPackageName(packageName: String): Int = throw UnsupportedOperationException("не поддерживается")

    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        val cm = getSystemService(ConnectivityManager::class.java)
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = pushDefault(cm, listener)
            override fun onLost(network: Network) = pushDefault(cm, listener)
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = pushDefault(cm, listener)
            override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) = pushDefault(cm, listener)
        }
        netCallback = cb
        cm.registerNetworkCallback(req, cb)
        pushDefault(cm, listener)
    }

    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        val cb = netCallback ?: return
        try {
            getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb)
        } catch (_: Exception) {
        }
        netCallback = null
    }

    private fun pushDefault(cm: ConnectivityManager, listener: InterfaceUpdateListener) {
        // исключение в колбэке сети не должно ронять приложение
        try {
            pushDefaultUnsafe(cm, listener)
        } catch (e: Throwable) {
            Log.w(TAG, "pushDefault", e)
        }
    }

    private fun pushDefaultUnsafe(cm: ConnectivityManager, listener: InterfaceUpdateListener) {
        var best: Network? = null
        var bestScore = -1
        for (n in cm.allNetworks) {
            val c = cm.getNetworkCapabilities(n) ?: continue
            if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            var score = when {
                c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 3
                c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 2
                c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 1
                else -> 0
            }
            if (c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) score += 10
            if (score > bestScore) {
                bestScore = score
                best = n
            }
        }
        val net = best
        val name = net?.let { cm.getLinkProperties(it)?.interfaceName }
        if (net == null || name == null) {
            listener.updateDefaultInterface("", -1, false, false)
            return
        }
        val index = try {
            JNetworkInterface.getByName(name)?.index ?: 0
        } catch (_: Exception) {
            0
        }
        val metered = cm.getNetworkCapabilities(net)
            ?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
        listener.updateDefaultInterface(name, index, metered, false)
    }

    override fun getInterfaces(): NetworkInterfaceIterator {
        val cm = getSystemService(ConnectivityManager::class.java)
        val javaIfaces = JNetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()
        val result = mutableListOf<BoxNetworkInterface>()
        for (n in cm.allNetworks) {
            val lp = cm.getLinkProperties(n) ?: continue
            val caps = cm.getNetworkCapabilities(n) ?: continue
            val name = lp.interfaceName ?: continue
            val ji = javaIfaces.find { it.name == name } ?: continue

            val bi = BoxNetworkInterface()
            bi.name = name
            bi.index = ji.index
            try {
                bi.mtu = ji.mtu
            } catch (_: Exception) {
            }
            // ВАЖНО: у IPv6-адресов hostAddress содержит зону ("fe80::1%wlan0"). Ядро разбирает
            // адреса через netip.MustParsePrefix, и с зоной оно паникует, роняя всё приложение.
            bi.dnsServer = StrIter(lp.dnsServers.mapNotNull { d -> d.hostAddress?.substringBefore('%') })
            bi.addresses = StrIter(ji.interfaceAddresses.mapNotNull { ia ->
                val host = ia.address?.hostAddress?.substringBefore('%') ?: return@mapNotNull null
                "$host/${ia.networkPrefixLength}"
            })
            bi.type = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Libbox.InterfaceTypeWIFI
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Libbox.InterfaceTypeCellular
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Libbox.InterfaceTypeEthernet
                else -> Libbox.InterfaceTypeOther
            }
            var flags = 0
            if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                flags = OsConstants.IFF_UP or OsConstants.IFF_RUNNING
            }
            if (ji.isLoopback) flags = flags or OsConstants.IFF_LOOPBACK
            if (ji.isPointToPoint) flags = flags or OsConstants.IFF_POINTOPOINT
            if (ji.supportsMulticast()) flags = flags or OsConstants.IFF_MULTICAST
            bi.flags = flags
            bi.metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            result.add(bi)
        }
        return object : NetworkInterfaceIterator {
            private val it = result.iterator()
            override fun hasNext() = it.hasNext()
            override fun next(): BoxNetworkInterface = it.next()
        }
    }

    override fun underNetworkExtension(): Boolean = false

    override fun includeAllNetworks(): Boolean = false

    override fun readWIFIState(): WIFIState? = null

    override fun clearDNSCache() {}

    override fun sendNotification(notification: BoxNotification) {}

    private class StrIter(private val items: List<String>) : StringIterator {
        private val it = items.iterator()
        override fun len(): Int = items.size
        override fun hasNext(): Boolean = it.hasNext()
        override fun next(): String = it.next()
    }

    companion object {
        const val TAG = "VpnBest"
        const val ACTION_START = "com.vpnbest.app.START"
        const val ACTION_STOP = "com.vpnbest.app.STOP"
        const val EXTRA_CONFIG = "config"
    }
}
