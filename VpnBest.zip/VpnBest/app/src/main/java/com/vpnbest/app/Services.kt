package com.vpnbest.app

/**
 * Сервисы, доступ к которым проверяется через каждый рабочий сервер. Приложение просто открывает страницу сервиса
 * через сервер и смотрит, ответил ли он: так видно, для чего сервер реально подходит с вашей сети.
 */
object Services {
    class Svc(val code: String, val title: String, val short: String, val url: String)

    val LIST = listOf(
        Svc("yt", "YouTube", "YT", "https://www.youtube.com/generate_204"),
        Svc("ds", "Discord", "DS", "https://discord.com/api/v9/gateway"),
        Svc("tg", "Telegram", "TG", "https://web.telegram.org/"),
        Svc("ig", "Instagram", "IG", "https://www.instagram.com/"),
        Svc("x", "X (Twitter)", "X", "https://x.com/"),
    )

    /** Универсальный: открываются YouTube и Discord и ещё хотя бы два сервиса из остальных. */
    fun isUniversal(codes: Set<String>): Boolean = "yt" in codes && "ds" in codes && codes.size >= 4

    fun byCode(code: String): Svc? = LIST.firstOrNull { it.code == code }

    /** «YT DS TG» — для строки сервера. */
    fun shortLine(codes: Set<String>): String =
        LIST.filter { it.code in codes }.joinToString(" ") { it.short }

    fun encode(codes: Set<String>): String = LIST.filter { it.code in codes }.joinToString(",") { it.code }

    fun decode(s: String): Set<String> =
        s.split(',').map { it.trim() }.filter { c -> LIST.any { it.code == c } }.toHashSet()
}
