package com.vpnbest.app

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Если приложение упало, причина сохраняется в файл и показывается при следующем запуске,
 * чтобы её можно было прочитать на телефоне без компьютера.
 * Сюда попадают и ошибки Kotlin/Java, и аварии Go-ядра (panic пишется в stderr).
 */
object CrashLog {
    private var installed = false
    private var redirected = false

    private fun javaFile(c: Context) = File(c.filesDir, "last_crash.txt")
    private fun goFile(c: Context) = File(c.filesDir, "go_stderr.log")

    @Synchronized
    fun install(c: Context) {
        if (installed) return
        installed = true
        val app = c.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                javaFile(app).writeText("Поток: ${t.name}\n$sw")
            } catch (_: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }

    /** Направляет stderr Go-ядра в файл. Вызывается через рефлексию, чтобы не зависеть от версии libbox. */
    @Synchronized
    fun redirectGoStderr(c: Context) {
        if (redirected) return
        redirected = true
        try {
            Class.forName("io.nekohasekai.libbox.Libbox")
                .getMethod("redirectStderr", String::class.java)
                .invoke(null, goFile(c).path)
        } catch (_: Throwable) {
        }
    }

    /** Текст прошлой аварии или null, если её не было. Читать нужно ДО redirectGoStderr. */
    fun read(c: Context): String? {
        val parts = ArrayList<String>()
        val j = javaFile(c)
        if (j.exists()) {
            runCatching { j.readText() }.getOrNull()?.takeIf { it.isNotBlank() }?.let { parts.add(it.take(2500)) }
        }
        val g = goFile(c)
        if (g.exists()) {
            val t = runCatching { g.readText() }.getOrNull().orEmpty()
            if (t.contains("panic") || t.contains("fatal error") || t.contains("SIGSEGV") || t.contains("goroutine")) {
                parts.add("Go-ядро:\n" + t.take(2500))
            }
        }
        clear(c)
        return if (parts.isEmpty()) null else parts.joinToString("\n\n")
    }

    @Synchronized
    private fun clear(c: Context) {
        runCatching { javaFile(c).delete() }
        runCatching { goFile(c).delete() }
        redirected = false // при следующем подключении stderr ядра снова пойдёт в новый файл
    }
}
