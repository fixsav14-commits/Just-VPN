package com.vpnbest.app

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class Server(
    val key: String,
    val name: String,
    val protocol: String,
    val host: String,
    val port: Int,
    val outbound: JSONObject,
    /** true — можно мерить пинг TCP-подключением (hysteria2 работает по UDP, его так не проверить) */
    val tcp: Boolean,
    val insecure: Boolean,
    /** из какого списка сервер: "BL", "CIDR", "SNI" или пусто (тогда смотрим на имя) */
    val group: String = "",
)

class UnsupportedServer(val id: String) : Exception("unsupported: $id")

object ServerParser {

    private val FINGERPRINTS = setOf(
        "chrome", "firefox", "edge", "safari", "360", "qq", "ios", "android", "random", "randomized"
    )

    /** Возвращает уникальные серверы и число уникальных, но неподдерживаемых (например, транспорт xhttp). */
    fun parseAll(lines: List<String>): Pair<List<Server>, Int> {
        val map = LinkedHashMap<String, Server>()
        val unsupported = HashSet<String>()
        var group = ""
        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#")) {
                // служебная строка «#group BL»: дальше идут серверы из этого списка
                if (line.startsWith("#group")) group = line.removePrefix("#group").trim()
                continue
            }
            try {
                val s = parse(line) ?: continue
                if (!map.containsKey(s.key)) map[s.key] = if (group.isNotEmpty()) s.copy(group = group) else s
            } catch (e: UnsupportedServer) {
                unsupported.add(e.id)
            } catch (e: Exception) {
                unsupported.add(line.take(60))
            }
        }
        return map.values.toList() to unsupported.size
    }

    fun parse(link: String): Server? {
        val scheme = link.substringBefore("://").lowercase()
        val rest = link.substringAfter("://")
        return when (scheme) {
            "vless" -> parseVless(rest)
            "trojan" -> parseTrojan(rest)
            "hysteria2", "hy2" -> parseHysteria2(rest)
            "vmess" -> parseVmess(rest)
            "ss" -> parseShadowsocks(rest)
            else -> null
        }
    }

    // ---------- разбор URI ----------

    private class Parts(
        val user: String,
        val host: String,
        val port: Int,
        val q: Map<String, String>,
        val name: String,
    )

    private fun split(rest: String): Parts {
        val frag = if (rest.contains('#')) rest.substringAfter('#') else ""
        val noFrag = rest.substringBefore('#')
        val query = if (noFrag.contains('?')) noFrag.substringAfter('?') else ""
        val main = noFrag.substringBefore('?')
        val at = main.lastIndexOf('@')
        val user = if (at >= 0) main.substring(0, at) else ""
        val hp = main.substring(at + 1).trimEnd('/')
        val host: String
        val port: Int
        if (hp.startsWith("[")) {
            host = hp.substring(1, hp.indexOf(']'))
            port = hp.substringAfter("]:").toInt()
        } else {
            host = hp.substringBeforeLast(':')
            port = hp.substringAfterLast(':').toInt()
        }
        val q = HashMap<String, String>()
        if (query.isNotEmpty()) {
            for (kv in query.split('&')) {
                val i = kv.indexOf('=')
                if (i > 0) q[kv.substring(0, i)] = Uri.decode(kv.substring(i + 1))
                else if (kv.isNotEmpty()) q[kv] = ""
            }
        }
        return Parts(Uri.decode(user), host, port, q, Uri.decode(frag))
    }

    private fun b64(s: String): String {
        var t = s.trim().replace('-', '+').replace('_', '/')
        while (t.length % 4 != 0) t += "="
        return String(Base64.decode(t, Base64.DEFAULT), Charsets.UTF_8)
    }

    private fun validHeader(h: String?): String? =
        h?.trim()?.takeIf { it.isNotEmpty() && !it.startsWith("/") && !it.startsWith("?") }

    private fun truthy(v: String?): Boolean = v == "1" || v.equals("true", ignoreCase = true)

    /** Имя узла для заголовка Host: без регистра и без точки на конце (как в SNI). */
    private fun hostName(h: String): String = h.lowercase().trimEnd('.')

    // ---------- TLS и транспорт ----------

    private fun tls(
        q: Map<String, String>,
        defaultTls: Boolean,
        transportType: String,
        allowUtls: Boolean,
    ): JSONObject? {
        val sec = q["security"] ?: if (defaultTls) "tls" else ""
        if (sec != "tls" && sec != "reality") return null

        val t = JSONObject().put("enabled", true)
        val sni = validHeader(q["sni"]) ?: validHeader(q["host"])
        if (sni != null) t.put("server_name", sni.lowercase().trimEnd('.'))
        if (truthy(q["allowInsecure"]) || truthy(q["insecure"])) t.put("insecure", true)

        var alpn = (q["alpn"] ?: "").split(',')
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("v2rayN") }
        if (transportType == "ws" || transportType == "httpupgrade") {
            alpn = alpn.filter { it == "http/1.1" }
        }
        if (alpn.isNotEmpty()) t.put("alpn", JSONArray(alpn))

        val fp = q["fp"]
        if (allowUtls && (sec == "reality" || fp in FINGERPRINTS)) {
            // отпечатки android и 360 в ядре sing-box ломают Reality («nil ecdhe_key»), сервер же на них не смотрит
            val use = when {
                fp !in FINGERPRINTS -> "chrome"
                sec == "reality" && (fp == "android" || fp == "360") -> "chrome"
                else -> fp
            }
            t.put("utls", JSONObject().put("enabled", true).put("fingerprint", use))
        }
        if (sec == "reality") {
            val pbk = q["pbk"] ?: throw UnsupportedServer("reality без pbk")
            t.put(
                "reality",
                JSONObject().put("enabled", true).put("public_key", pbk).put("short_id", q["sid"] ?: "")
            )
        }
        return t
    }

    private fun transport(type: String, q: Map<String, String>): JSONObject? {
        return when (type) {
            "", "tcp", "raw" -> null
            "ws" -> {
                var path = q["path"]?.ifEmpty { "/" } ?: "/"
                // «?ed=2048» в пути — это ранние данные в стиле Xray: в сам путь они не входят
                var early = 0
                val m = Regex("""([?&])ed=(\d+)""").find(path)
                if (m != null) {
                    early = m.groupValues[2].toInt()
                    val rest = path.replaceFirst(m.value, "")
                    path = if (m.groupValues[1] == "?" && rest.contains("&") && !rest.contains("?"))
                        rest.replaceFirst("&", "?") else rest
                    if (path.isEmpty()) path = "/"
                }
                val o = JSONObject().put("type", "ws").put("path", path)
                if (early > 0) {
                    o.put("max_early_data", early).put("early_data_header_name", "Sec-WebSocket-Protocol")
                }
                validHeader(q["host"])?.let { o.put("headers", JSONObject().put("Host", hostName(it))) }
                o
            }
            "grpc" -> JSONObject().put("type", "grpc").put("service_name", q["serviceName"] ?: "")
            "httpupgrade" -> {
                val o = JSONObject().put("type", "httpupgrade").put("path", q["path"]?.ifEmpty { "/" } ?: "/")
                validHeader(q["host"])?.let { o.put("host", hostName(it)) }
                o
            }
            else -> throw UnsupportedServer("транспорт $type")
        }
    }

    // ---------- протоколы ----------

    private fun parseVless(rest: String): Server {
        val p = split(rest)
        val type = p.q["type"] ?: "tcp"
        val ob = JSONObject()
            .put("type", "vless").put("tag", "proxy")
            .put("server", p.host).put("server_port", p.port)
            .put("uuid", p.user)
            .put("packet_encoding", "xudp")
        p.q["flow"]?.takeIf { it.isNotEmpty() }?.let { ob.put("flow", it) }
        tls(p.q, false, type, true)?.let { ob.put("tls", it) }
        transport(type, p.q)?.let { ob.put("transport", it) }
        return make("vless", p, ob, true)
    }

    private fun parseTrojan(rest: String): Server {
        val p = split(rest)
        val type = p.q["type"] ?: "tcp"
        val ob = JSONObject()
            .put("type", "trojan").put("tag", "proxy")
            .put("server", p.host).put("server_port", p.port)
            .put("password", p.user)
        tls(p.q, true, type, true)?.let { ob.put("tls", it) }
        transport(type, p.q)?.let { ob.put("transport", it) }
        return make("trojan", p, ob, true)
    }

    private fun parseHysteria2(rest: String): Server {
        val p = split(rest)
        val ob = JSONObject()
            .put("type", "hysteria2").put("tag", "proxy")
            .put("server", p.host).put("server_port", p.port)
            .put("password", p.user)
        val t = tls(p.q, true, "", false) ?: JSONObject().put("enabled", true)
        if (!t.has("alpn")) t.put("alpn", JSONArray().put("h3"))
        ob.put("tls", t)
        return make("hysteria2", p, ob, false)
    }

    private fun parseVmess(rest: String): Server {
        val j = JSONObject(b64(rest.substringBefore('#')))
        val host = j.getString("add")
        val port = j.get("port").toString().toInt()
        val net = j.optString("net", "tcp")
        val q = HashMap<String, String>()
        q["path"] = j.optString("path", "")
        q["host"] = j.optString("host", "")
        q["sni"] = j.optString("sni", "")
        q["alpn"] = j.optString("alpn", "")
        q["fp"] = j.optString("fp", "")
        q["serviceName"] = j.optString("path", "")
        val tlsOn = j.optString("tls", "").let { it == "tls" || it == "true" }
        if (tlsOn) q["security"] = "tls"

        val ob = JSONObject()
            .put("type", "vmess").put("tag", "proxy")
            .put("server", host).put("server_port", port)
            .put("uuid", j.getString("id"))
            .put("security", j.optString("scy", "auto").ifEmpty { "auto" })
            .put("alter_id", j.optString("aid", "0").toIntOrNull() ?: 0)
        tls(q, false, net, true)?.let { ob.put("tls", it) }
        transport(net, q)?.let { ob.put("transport", it) }
        val name = j.optString("ps", "").ifEmpty { host }
        return make("vmess", Parts("", host, port, q, name), ob, true)
    }

    private fun parseShadowsocks(rest: String): Server {
        val p = split(rest)
        val cred = b64(p.user)
        val method = cred.substringBefore(':')
        val password = cred.substringAfter(':')
        val ob = JSONObject()
            .put("type", "shadowsocks").put("tag", "proxy")
            .put("server", p.host).put("server_port", p.port)
            .put("method", method).put("password", password)
        return make("ss", p, ob, true)
    }

    private fun make(protocol: String, p: Parts, ob: JSONObject, tcp: Boolean): Server {
        // ключ не зависит от отпечатка браузера и ALPN: такие варианты — один и тот же сервер
        val k = JSONObject(ob.toString())
        k.optJSONObject("tls")?.let { it.remove("utls"); it.remove("alpn") }
        val md = MessageDigest.getInstance("MD5").digest(k.toString().toByteArray())
        val key = md.joinToString("") { "%02x".format(it) }
        val insecure = ob.optJSONObject("tls")?.optBoolean("insecure", false) ?: false
        return Server(
            key = key,
            name = p.name.ifEmpty { p.host },
            protocol = protocol,
            host = p.host,
            port = p.port,
            outbound = ob,
            tcp = tcp,
            insecure = insecure,
        )
    }
}
