package com.vpnbest.app

import org.json.JSONObject
import java.net.ConnectException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NoRouteToHostException
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection

/** Результат предварительной проверки перед замером. */
class PrepResult(
    /** имя сервера -> IPv4, который мы узнали заранее */
    val pins: Map<String, String>,
    /** ключ сервера -> короткая причина, почему до него не дойти (такие серверы в замер не берём) */
    val unreachable: Map<String, String>,
    /** ключ сервера -> время TCP-соединения, мс (только у тех, до кого дошли) */
    val tcpMs: Map<String, Int>,
)

/**
 * Быстрая проверка до замера, секунд за 5–10:
 * 1) узнаём IP серверов, заданных именем (DoH, потом системный DNS: провайдерский DNS у нас часто
 *    подменяет адреса заблокированных сайтов);
 * 2) пробуем обычное TCP-соединение с каждым сервером. Если до адреса не дойти вообще, настоящий
 *    запрос через него бессмысленен, и мы не тратим на него время замера.
 * hysteria2 работает по UDP, его TCP-проверка не касается.
 */
object Prep {

    private val daemon = ThreadFactory { r -> Thread(r).apply { isDaemon = true } }

    fun isIp(h: String) = h.isNotEmpty() && (h.contains(':') || h.all { it.isDigit() || it == '.' })

    private fun okIp(ip: String): Boolean =
        ip.isNotEmpty() && !ip.startsWith("0.") && !ip.startsWith("127.") && ip != "255.255.255.255"

    @Volatile
    private var dohCache: Pair<Long, Boolean>? = null

    /** Достижим ли DoH с этой сети (результат помним минуту). Если нет, к нему не обращаемся: это лишние секунды. */
    fun dohWorks(): Boolean {
        val c = dohCache
        val now = System.currentTimeMillis()
        if (c != null && now - c.first < 60_000) return c.second
        val ok = doh("https://1.1.1.1/dns-query?name=cp.cloudflare.com&type=A") != null ||
            doh("https://8.8.8.8/resolve?name=cp.cloudflare.com&type=A") != null
        dohCache = now to ok
        return ok
    }

    /** IPv4-адрес для имени или null. */
    fun resolve(host: String): String? {
        if (isIp(host)) return null
        if (dohWorks()) {
            doh("https://1.1.1.1/dns-query?name=$host&type=A")?.let { return it }
            doh("https://8.8.8.8/resolve?name=$host&type=A")?.let { return it }
        }
        return try {
            InetAddress.getAllByName(host).firstOrNull { it is Inet4Address }?.hostAddress?.takeIf { okIp(it) }
        } catch (_: Throwable) {
            null
        }
    }

    private fun doh(url: String): String? {
        return try {
            val c = URL(url).openConnection() as HttpsURLConnection
            c.connectTimeout = 2500
            c.readTimeout = 2500
            c.setRequestProperty("accept", "application/dns-json")
            if (c.responseCode != 200) return null
            val body = c.inputStream.bufferedReader().readText()
            c.disconnect()
            val ans = JSONObject(body).optJSONArray("Answer") ?: return null
            for (i in 0 until ans.length()) {
                val a = ans.getJSONObject(i)
                if (a.optInt("type") == 1) {
                    val ip = a.optString("data")
                    if (okIp(ip)) return ip
                }
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun reason(e: Throwable): String = when {
        e is SocketTimeoutException -> "Тайм-аут"
        e is ConnectException && (e.message ?: "").contains("refused", true) -> "Отказ"
        e is NoRouteToHostException -> "Нет маршрута"
        e is ConnectException && (e.message ?: "").let { it.contains("unreachable", true) || it.contains("route", true) } ->
            "Нет маршрута"
        e is UnknownHostException -> "Нет DNS"
        else -> "Тайм-аут"
    }

    fun run(servers: List<Server>, cancelled: () -> Boolean): PrepResult {
        // 1) имена -> IP
        val hosts = servers.map { it.host }.filter { !isIp(it) }.distinct()
        val pins = HashMap<String, String>()
        if (hosts.isNotEmpty()) {
            AppLog.add("DNS-over-HTTPS " + (if (dohWorks()) "доступен" else "недоступен, беру системный DNS"))
            val pool = Executors.newFixedThreadPool(96, daemon)
            val latch = CountDownLatch(hosts.size)
            for (h in hosts) {
                pool.execute {
                    try {
                        resolve(h)?.let { synchronized(pins) { pins[h] = it } }
                    } catch (_: Throwable) {
                    } finally {
                        latch.countDown()
                    }
                }
            }
            latch.await(14, TimeUnit.SECONDS)
            pool.shutdownNow()
        }
        AppLog.add("DNS: узнал адрес у ${pins.size} из ${hosts.size} имён")

        // 2) TCP-доступность
        val unreachable = HashMap<String, String>()
        val tcpMs = HashMap<String, Int>()
        val tcpServers = servers.filter { it.tcp }
        if (!cancelled()) {
            val pool = Executors.newFixedThreadPool(320, daemon)
            val latch = CountDownLatch(servers.size)
            for (s in servers) {
                pool.execute {
                    try {
                        val ip = if (isIp(s.host)) s.host else pins[s.host]
                        if (ip == null) {
                            synchronized(unreachable) { unreachable[s.key] = "Нет DNS" }
                        } else if (s.tcp) {
                            val t0 = System.nanoTime()
                            try {
                                Socket().use { sock ->
                                    sock.connect(InetSocketAddress(ip, s.port), 4000)
                                }
                                val ms = ((System.nanoTime() - t0) / 1_000_000).toInt()
                                synchronized(tcpMs) { tcpMs[s.key] = ms }
                            } catch (e: Throwable) {
                                synchronized(unreachable) { unreachable[s.key] = reason(e) }
                            }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        latch.countDown()
                    }
                }
            }
            latch.await(22, TimeUnit.SECONDS)
            pool.shutdownNow()
        }
        AppLog.add(
            "TCP: дошли до ${tcpMs.size} из ${tcpServers.size} серверов, " +
                "недоступно ${unreachable.size} (отказ/тайм-аут/нет DNS)"
        )
        return PrepResult(pins, unreachable, tcpMs)
    }
}
