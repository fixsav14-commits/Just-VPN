package com.vpnbest.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Журнал событий приложения и ядра. Показывается кнопкой «Журнал»: по нему видно, что пошло не так. */
object AppLog {
    private const val MAX = 600
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(msg: String) {
        lines.addLast(fmt.format(Date()) + " " + msg.take(400))
        while (lines.size > MAX) lines.removeFirst()
    }

    @Synchronized
    fun text(): String = lines.joinToString("\n")

    @Synchronized
    fun clear() {
        lines.clear()
    }
}
