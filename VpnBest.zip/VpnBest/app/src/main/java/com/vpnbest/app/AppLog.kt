package com.vpnbest.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Журнал событий приложения и ядра. Показывается кнопкой «Журнал»: по нему видно, что пошло не так. */
object AppLog {
    private const val MAX = 3000
    // цветовые коды ядра (ESC в начале может потеряться по дороге, поэтому он необязателен)
    private val ansi = Regex("\u001B?\\[[0-9;]*m")
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(msg: String) {
        lines.addLast(fmt.format(Date()) + " " + ansi.replace(msg, "").take(300))
        while (lines.size > MAX) lines.removeFirst()
    }

    @Synchronized
    fun text(): String = lines.joinToString("\n")

    @Synchronized
    fun clear() {
        lines.clear()
    }
}
