package com.vpnbest.app

import android.os.SystemClock
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.SocketTimeoutException
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.ThreadFactory
import java.util.concurrent.TimeUnit

/** Результаты проверок одного сервера. */
class Stat {
    var ok = 0
        private set
    var total = 0
        private set
    private var sum = 0L

    /** Уточнённый пинг (мс) из второго этапа замера; 0 — не уточняли. */
    @Volatile
    var ping = 0

    /** Почему сервер не ответил (последняя неудача): «Тайм-аут», «Отказ» и т. п. */
    @Volatile
    var reason: String? = null

    @Synchronized
    fun record(ms: Int?) {
        total++
        if (ms != null) {
            ok++
            sum += ms
        }
    }

    @Synchronized
    fun avg(): Int? = if (ok == 0) null else if (ping > 0) ping else (sum / ok).toInt()

    @Synchronized
    fun loss(): Double = if (total == 0) 1.0 else 1.0 - ok.toDouble() / total

    /** Чем меньше, тем лучше: средняя задержка плюс штраф за неудачные попытки. */
    @Synchronized
    fun score(): Double? {
        val a = avg() ?: return null
        return a + loss() * 400.0
    }
}

/**
 * Настоящий замер, как в v2rayN/v2Box: ядро поднимает локальный HTTP-прокси на каждый сервер
 * (порт basePort + номер сервера), и мы делаем HTTPS-запрос через каждый. Задержка измеряется
 * по реальному ответу, поэтому нерабочие серверы с открытым портом отсеиваются.
 */
class RealProbe(
    private val servers: List<Server>,
    private val basePort: Int,
    private val durationMs: Long,
    private val onProgress: (round: Int, remainingMs: Long, stats: List<Stat>) -> Unit,
    private val onDone: (stats: List<Stat>, cancelled: Boolean) -> Unit,
    private val onStage: (text: String) -> Unit = {},
) {
    @Volatile
    private var cancelled = false
    private val stats: List<Stat> = List(servers.size) { Stat() }

    // не больше двух одновременных запросов на один адрес: иначе сервер отвечает 429 и «лжёт»
    private val perEndpoint = HashMap<String, Semaphore>().also { m ->
        for (s in servers) m.getOrPut(endpoint(s)) { Semaphore(2) }
    }

    fun cancel() {
        cancelled = true
    }

    fun start() {
        Thread { runProbe() }.apply { isDaemon = true }.start()
    }

    private fun runProbe() {
        val pool = Executors.newFixedThreadPool(POOL, ThreadFactory { r -> Thread(r).apply { isDaemon = true } })
        val end = SystemClock.elapsedRealtime() + durationMs
        var round = 0

        while (!cancelled && SystemClock.elapsedRealtime() < end) {
            round++
            val roundStart = SystemClock.elapsedRealtime()

            // рабочему хватает трёх ответов, не отвечавшему две попытки, дальше сервер не проверяем
            val targets = ArrayList<Int>()
            for (i in servers.indices) {
                val st = stats[i]
                if (needMore(st.ok, st.total)) targets.add(i)
            }
            if (targets.isEmpty()) break // все проверены достаточно

            val latch = CountDownLatch(targets.size)
            for (i in targets) {
                pool.execute {
                    val sem = perEndpoint[endpoint(servers[i])]
                    try {
                        sem?.acquire()
                        if (!cancelled && SystemClock.elapsedRealtime() < end + 4000) {
                            probeOnce(basePort + i, stats[i])
                        }
                    } catch (_: Throwable) {
                    } finally {
                        sem?.release()
                        latch.countDown()
                    }
                }
            }
            // раунд не длиннее времени до конца замера (плюс запас на последние ответы)
            val hardStop = minOf(end + 4000, SystemClock.elapsedRealtime() + 60_000)
            while (!latch.await(500, TimeUnit.MILLISECONDS)) {
                if (cancelled || SystemClock.elapsedRealtime() > hardStop) break
                onProgress(round, maxOf(0L, end - SystemClock.elapsedRealtime()), stats)
            }
            onProgress(round, maxOf(0L, end - SystemClock.elapsedRealtime()), stats)

            // раунды идут не чаще раза в 5 секунд, чтобы не долбить серверы без остановки
            while (!cancelled && SystemClock.elapsedRealtime() < end &&
                SystemClock.elapsedRealtime() < roundStart + 5_000
            ) {
                Thread.sleep(250)
            }
        }
        pool.shutdownNow()
        if (!cancelled) {
            onStage("Уточняю пинг у лучших серверов…")
            refinePing()
        }
        onDone(stats, cancelled)
    }

    /**
     * Второй этап замера. Сотня одновременных запросов раздувает задержку, а каждый запрос заново открывает
     * соединение (это 3–4 круговых пути). Здесь лучшие серверы проверяются понемногу и на одном соединении:
     * пинг — это время ответа на уже открытом соединении, как у обычного ping.
     */
    private fun refinePing() {
        val top = rank(servers, stats, 15)
        if (top.isEmpty()) return
        val pos = HashMap<Server, Int>()
        for ((i, s) in servers.withIndex()) pos[s] = i
        val pool = Executors.newFixedThreadPool(5, ThreadFactory { r -> Thread(r).apply { isDaemon = true } })
        val latch = CountDownLatch(top.size)
        val deadline = SystemClock.elapsedRealtime() + 25_000
        for (s in top) {
            val i = pos[s] ?: continue
            pool.execute {
                try {
                    if (!cancelled && SystemClock.elapsedRealtime() < deadline) {
                        val ms = warmPing(basePort + i)
                        if (ms > 0) stats[i].ping = ms
                    }
                } catch (_: Throwable) {
                } finally {
                    latch.countDown()
                }
            }
        }
        latch.await(28, TimeUnit.SECONDS)
        pool.shutdownNow()
    }

    /** Четыре запроса подряд на одном соединении: первый (установка соединения) не считаем, пинг — середина остальных. */
    private fun warmPing(port: Int): Int {
        val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", port))
        val ms = ArrayList<Int>()
        for (k in 0 until 4) {
            if (cancelled) break
            try {
                val t0 = System.nanoTime()
                val conn = URL(CHECK_URL).openConnection(proxy) as HttpURLConnection
                conn.connectTimeout = 6000
                conn.readTimeout = ATTEMPT_MS
                conn.useCaches = false
                conn.instanceFollowRedirects = false
                val code = conn.responseCode
                // читаем и закрываем поток, не отключаясь: тогда соединение остаётся для следующего запроса
                try {
                    conn.inputStream.use { ins -> while (ins.read(ByteArray(1024)) >= 0) { /* тела нет */ } }
                } catch (_: Throwable) {
                }
                if (k > 0 && code in 200..399) ms.add(((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1))
            } catch (_: Throwable) {
                if (k == 0) return 0
            }
        }
        if (ms.size < 2) return 0
        ms.sort()
        return ms[(ms.size - 1) / 2]
    }

    /** Один запрос через сервер: записывает задержку или причину неудачи. */
    private fun probeOnce(port: Int, st: Stat) {
        var c: HttpURLConnection? = null
        try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", port))
            val t0 = System.nanoTime()
            val conn = URL(CHECK_URL).openConnection(proxy) as HttpURLConnection
            c = conn
            conn.connectTimeout = 6000
            conn.readTimeout = ATTEMPT_MS
            conn.useCaches = false
            conn.instanceFollowRedirects = false
            val code = conn.responseCode
            if (code in 200..399) {
                st.record(((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1))
            } else {
                st.reason = "Ответ $code"
                st.record(null)
            }
        } catch (e: Throwable) {
            val m = e.message ?: ""
            st.reason = when {
                e is SocketTimeoutException -> "Тайм-аут"
                m.contains("tunnel", true) -> "Сервер не отвечает"
                else -> "Ошибка"
            }
            st.record(null)
        } finally {
            try {
                c?.disconnect()
            } catch (_: Throwable) {
            }
        }
    }

    companion object {
        const val CHECK_URL = "https://cp.cloudflare.com/generate_204"
        const val ATTEMPT_MS = 8000 // мёртвый сервер не должен держать место в очереди дольше
        const val POOL = 128 // запросов одновременно

        /** Нужна ли серверу ещё проверка: рабочему хватает трёх ответов, не отвечавшему двух попыток. */
        fun needMore(ok: Int, total: Int): Boolean = if (ok > 0) total < 3 else total < 2

        /** Сколько времени отвести на весь замер вместе с подготовкой: минута, а для большого списка до двух. */
        fun budgetMs(n: Int): Long = minOf(120_000L, 60_000L + maxOf(0, n - 150) * 120L)

        fun endpoint(s: Server) = "${s.host}:${s.port}"

        /** Рабочие серверы от лучшего к худшему. Не больше трёх на один адрес, всего не больше [limit]. */
        fun rank(list: List<Server>, st: List<Stat>, limit: Int = 10): List<Server> {
            val scored = ArrayList<Pair<Server, Double>>()
            for (i in list.indices) {
                val s = st[i]
                if (s.ok == 0) continue
                if (s.total >= 3 && s.loss() > 0.5) continue
                val sc = s.score() ?: continue
                scored.add(list[i] to sc)
            }
            scored.sortBy { it.second }
            val perEp = HashMap<String, Int>()
            val result = ArrayList<Server>()
            for (item in scored) {
                val ep = endpoint(item.first)
                val n = perEp[ep] ?: 0
                if (n >= 3) continue
                perEp[ep] = n + 1
                result.add(item.first)
                if (result.size >= limit) break
            }
            return result
        }
    }
}
