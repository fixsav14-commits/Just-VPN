package com.vpnbest.app

import android.os.SystemClock
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.SocketTimeoutException
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.ThreadFactory
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** Результаты проверок одного сервера. */
class Stat {
    var ok = 0
        private set
    var total = 0
        private set
    private var sum = 0L

    /** Уточнённый пинг (мс) из второго этапа замера; 0 — не уточняли. */
    @Volatile
    var ping = 0

    /** Почему сервер не ответил (последняя неудача): «Тайм-аут», «Отказ» и т. п. */
    @Volatile
    var reason: String? = null

    /** Проверялись ли сервисы (YouTube, Discord…) через этот сервер, и какие из них открылись. */
    @Volatile
    var svcDone = false
    private val svcOk = HashSet<String>()

    @Synchronized
    fun addSvc(code: String) {
        svcOk.add(code)
    }

    @Synchronized
    fun svcSet(): Set<String> = HashSet(svcOk)

    /** Сервер ответил на первом этапе, но не выдержал перепроверку: считаем нерабочим. */
    @Synchronized
    fun invalidate(why: String) {
        ok = 0
        sum = 0
        ping = 0
        total++
        reason = why
    }

    @Synchronized
    fun record(ms: Int?) {
        total++
        if (ms != null) {
            ok++
            sum += ms
        }
    }

    @Synchronized
    fun avg(): Int? = if (ok == 0) null else if (ping > 0) ping else (sum / ok).toInt()

    @Synchronized
    fun loss(): Double = if (total == 0) 1.0 else 1.0 - ok.toDouble() / total

    /** Чем меньше, тем лучше: средняя задержка плюс штраф за неудачные попытки. */
    @Synchronized
    fun score(): Double? {
        val a = avg() ?: return null
        return a + loss() * 400.0
    }
}

/**
 * Замер в два этапа, как в v2rayN/v2Box: ядро поднимает локальный HTTP-прокси на каждый сервер
 * (порт basePort + номер сервера), и мы делаем настоящий HTTPS-запрос через каждый.
 *
 * Этап 1 — пинг: по одному запросу через каждый сервер (серверы с UDP в конце очереди).
 * Этап 2 — перепроверка: лучшие из ответивших проверяются ещё раз на одном соединении (так получается честный пинг),
 * и заодно через них открываются YouTube, Discord, Telegram, Instagram и X. Не выдержавшие перепроверку считаются нерабочими.
 * Замер заканчивается сразу, как закончился второй этап: фиксированного времени нет.
 */
class RealProbe(
    private val servers: List<Server>,
    private val basePort: Int,
    private val onProgress: (stage: Int, done: Int, total: Int, stats: List<Stat>) -> Unit,
    private val onDone: (stats: List<Stat>, cancelled: Boolean) -> Unit,
    private val onStage: (text: String) -> Unit = {},
    private val checkServices: Boolean = true,
) {
    @Volatile
    private var cancelled = false
    private val stats: List<Stat> = List(servers.size) { Stat() }

    /** Сколько серверов hysteria2 не проверялось, потому что UDP с этой сети, похоже, закрыт. */
    @Volatile
    var udpSkipped = 0
        private set

    /** Итоги этапов для журнала: сколько ответило на первом, сколько перепроверялось и сколько выдержало. */
    @Volatile
    var stage1Ok = 0
        private set

    @Volatile
    var recheckTotal = 0
        private set

    @Volatile
    var recheckPassed = 0
        private set

    // не больше двух одновременных запросов на один адрес: иначе сервер отвечает 429 и «лжёт»
    private val perEndpoint = HashMap<String, Semaphore>().also { m ->
        for (s in servers) m.getOrPut(endpoint(s)) { Semaphore(2) }
    }

    fun cancel() {
        cancelled = true
    }

    fun start() {
        Thread { runProbe() }.apply { isDaemon = true }.start()
    }

    private fun daemonPool(n: Int) = Executors.newFixedThreadPool(n, ThreadFactory { r -> Thread(r).apply { isDaemon = true } })

    private fun runProbe() {
        try {
            stage1()
            if (!cancelled) stage2()
        } catch (_: Throwable) {
        }
        onDone(stats, cancelled)
    }

    // ---------- этап 1: пинг ----------

    private fun stage1() {
        val total = servers.size
        val pool = daemonPool(POOL)
        val deadline = SystemClock.elapsedRealtime() + STAGE1_MAX_MS
        val finished = AtomicInteger()
        val udpSem = Semaphore(UDP_PARALLEL)
        val udpOk = AtomicInteger()
        val skipped = AtomicInteger()
        // сначала обычные серверы, серверы с UDP в конце: они не должны задерживать остальных
        val order = servers.indices.filter { servers[it].tcp } + servers.indices.filter { !servers[it].tcp }
        // Первые 30 серверов hysteria2 — «разведка». Если ни один не ответил, UDP с этой сети закрыт (так делают многие
        // операторы), и остальных мы не проверяем. Остальные ждут у ворот, пока разведка закончится.
        val udpPos = HashMap<Int, Int>()
        servers.indices.filter { !servers[it].tcp }.forEachIndexed { pos, i -> udpPos[i] = pos }
        val gate = CountDownLatch(minOf(UDP_PARALLEL, udpPos.size))
        val latch = CountDownLatch(order.size)
        for (i in order) {
            pool.execute {
                val sem = perEndpoint[endpoint(servers[i])]
                val pos = udpPos[i] ?: -1 // номер среди серверов с UDP, -1 — обычный сервер
                var udpLocked = false
                try {
                    if (pos >= UDP_PARALLEL) {
                        gate.await(STAGE1_MAX_MS, TimeUnit.MILLISECONDS)
                        if (udpOk.get() == 0) {
                            stats[i].reason = "UDP закрыт"
                            stats[i].record(null)
                            skipped.incrementAndGet()
                            return@execute
                        }
                    }
                    if (pos >= 0) {
                        udpSem.acquire()
                        udpLocked = true
                    }
                    sem?.acquire()
                    try {
                        if (!cancelled && SystemClock.elapsedRealtime() < deadline) {
                            probeOnce(basePort + i, stats[i])
                        } else if (!cancelled) {
                            stats[i].reason = "Не успел"
                            stats[i].record(null)
                        }
                    } finally {
                        sem?.release()
                    }
                    if (pos >= 0 && stats[i].ok > 0) udpOk.incrementAndGet()
                } catch (_: Throwable) {
                } finally {
                    if (udpLocked) udpSem.release()
                    if (pos in 0 until UDP_PARALLEL) gate.countDown()
                    finished.incrementAndGet()
                    latch.countDown()
                }
            }
        }
        val hardStop = deadline + 9000
        while (!latch.await(400, TimeUnit.MILLISECONDS)) {
            if (cancelled || SystemClock.elapsedRealtime() > hardStop) break
            onProgress(1, finished.get(), total, stats)
        }
        onProgress(1, finished.get(), total, stats)
        pool.shutdownNow()
        udpSkipped = skipped.get()
        stage1Ok = stats.count { it.ok > 0 }
    }

    // ---------- этап 2: перепроверка ----------

    private fun stage2() {
        val top = servers.indices
            .filter { stats[it].ok > 0 }
            .sortedBy { stats[it].score() ?: Double.MAX_VALUE }
            .take(RECHECK_LIMIT)
        recheckTotal = top.size
        if (top.isEmpty()) return
        onStage(
            "Этап 2 из 2: перепроверка ${top.size} лучших серверов" +
                (if (checkServices) " и проверка YouTube, Discord, Telegram, Instagram, X" else "") + "…"
        )
        val pool = daemonPool(RECHECK_THREADS)
        val latch = CountDownLatch(top.size)
        val deadline = SystemClock.elapsedRealtime() + RECHECK_BUDGET_MS
        val finished = AtomicInteger()
        val passed = AtomicInteger()
        for (i in top) {
            pool.execute {
                val sem = perEndpoint[endpoint(servers[i])]
                try {
                    sem?.acquire()
                    if (!cancelled && SystemClock.elapsedRealtime() < deadline) {
                        if (recheckOne(i, deadline)) passed.incrementAndGet()
                    } else if (!cancelled) {
                        passed.incrementAndGet() // не дошла очередь: остаётся с результатом первого этапа
                    }
                } catch (_: Throwable) {
                } finally {
                    sem?.release()
                    finished.incrementAndGet()
                    latch.countDown()
                }
            }
        }
        val hardStop = deadline + 8000
        while (!latch.await(400, TimeUnit.MILLISECONDS)) {
            if (cancelled || SystemClock.elapsedRealtime() > hardStop) break
            onProgress(2, finished.get(), top.size, stats)
        }
        onProgress(2, finished.get(), top.size, stats)
        pool.shutdownNow()
        recheckPassed = passed.get()
    }

    /** Перепроверка одного сервера; false — не выдержал. */
    private fun recheckOne(i: Int, deadline: Long): Boolean {
        val st = stats[i]
        val port = basePort + i
        val ms = warmPing(port)
        if (ms <= 0) {
            st.invalidate("Не прошёл перепроверку")
            return false
        }
        st.ping = ms
        if (!checkServices) return true
        var done = 0
        for (svc in Services.LIST) {
            if (cancelled || SystemClock.elapsedRealtime() >= deadline) break
            if (checkService(port, svc.url)) st.addSvc(svc.code)
            done++
        }
        // «проверено» — только если дошли все проверки сервера; иначе метки не ставим, чтобы не соврать
        if (done >= Services.LIST.size) st.svcDone = true
        return true
    }

    /** Четыре запроса подряд на одном соединении: первый (установка соединения) не считаем, пинг — середина остальных. */
    private fun warmPing(port: Int): Int {
        val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", port))
        val ms = ArrayList<Int>()
        for (k in 0 until 4) {
            if (cancelled) break
            try {
                val t0 = System.nanoTime()
                val conn = URL(CHECK_URL).openConnection(proxy) as HttpURLConnection
                conn.connectTimeout = 6000
                conn.readTimeout = ATTEMPT_MS
                conn.useCaches = false
                conn.instanceFollowRedirects = false
                val code = conn.responseCode
                // читаем и закрываем поток, не отключаясь: тогда соединение остаётся для следующего запроса
                try {
                    conn.inputStream.use { ins -> while (ins.read(ByteArray(1024)) >= 0) { /* тела нет */ } }
                } catch (_: Throwable) {
                }
                if (k > 0 && code in 200..399) ms.add(((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1))
            } catch (_: Throwable) {
                if (k == 0) return 0
            }
        }
        if (ms.size < 2) return 0
        ms.sort()
        return ms[(ms.size - 1) / 2]
    }

    /** Открывается ли страница через сервер: любой ответ 2xx–3xx считаем успехом. */
    private fun checkService(port: Int, url: String): Boolean {
        var c: HttpURLConnection? = null
        return try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", port))
            val conn = URL(url).openConnection(proxy) as HttpURLConnection
            c = conn
            conn.connectTimeout = 6000
            conn.readTimeout = 7000
            conn.useCaches = false
            conn.instanceFollowRedirects = false
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
            )
            conn.responseCode in 200..399
        } catch (_: Throwable) {
            false
        } finally {
            try {
                c?.disconnect()
            } catch (_: Throwable) {
            }
        }
    }

    /** Один запрос через сервер: записывает задержку или причину неудачи. */
    private fun probeOnce(port: Int, st: Stat) {
        var c: HttpURLConnection? = null
        try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", port))
            val t0 = System.nanoTime()
            val conn = URL(CHECK_URL).openConnection(proxy) as HttpURLConnection
            c = conn
            conn.connectTimeout = 6000
            conn.readTimeout = ATTEMPT_MS
            conn.useCaches = false
            conn.instanceFollowRedirects = false
            val code = conn.responseCode
            if (code in 200..399) {
                st.record(((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1))
            } else {
                st.reason = "Ответ $code"
                st.record(null)
            }
        } catch (e: Throwable) {
            val m = e.message ?: ""
            st.reason = when {
                e is SocketTimeoutException -> "Тайм-аут"
                m.contains("tunnel", true) -> "Сервер не отвечает"
                else -> "Ошибка"
            }
            st.record(null)
        } finally {
            try {
                c?.disconnect()
            } catch (_: Throwable) {
            }
        }
    }

    companion object {
        const val CHECK_URL = "https://cp.cloudflare.com/generate_204"
        const val ATTEMPT_MS = 7000 // мёртвый сервер не должен держать место в очереди дольше
        const val POOL = 128 // запросов одновременно на первом этапе
        const val RECHECK_THREADS = 24 // серверов одновременно на втором этапе
        const val RECHECK_LIMIT = 100 // сколько лучших серверов перепроверяем на втором этапе
        const val RECHECK_BUDGET_MS = 35_000L // второй этап не длиннее этого
        const val STAGE1_MAX_MS = 45_000L // первый этап не длиннее этого (обычно заканчивается раньше)
        const val UDP_PARALLEL = 30 // серверов hysteria2 одновременно: если первые 30 молчат, остальных не проверяем

        fun endpoint(s: Server) = "${s.host}:${s.port}"

        /** Рабочие серверы от лучшего к худшему. Не больше трёх на один адрес, всего не больше [limit]. */
        fun rank(list: List<Server>, st: List<Stat>, limit: Int = 10): List<Server> {
            val scored = ArrayList<Pair<Server, Double>>()
            for (i in list.indices) {
                val s = st[i]
                if (s.ok == 0) continue
                if (s.total >= 3 && s.loss() > 0.5) continue
                val sc = s.score() ?: continue
                scored.add(list[i] to sc)
            }
            scored.sortBy { it.second }
            val perEp = HashMap<String, Int>()
            val result = ArrayList<Server>()
            for (item in scored) {
                val ep = endpoint(item.first)
                val n = perEp[ep] ?: 0
                if (n >= 3) continue
                perEp[ep] = n + 1
                result.add(item.first)
                if (result.size >= limit) break
            }
            return result
        }
    }
}
