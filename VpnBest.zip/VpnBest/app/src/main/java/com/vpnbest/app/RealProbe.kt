package com.vpnbest.app

import android.os.SystemClock
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Результаты проверок одного сервера. */
class Stat {
    var ok = 0
        private set
    var total = 0
        private set
    private var sum = 0L

    @Synchronized
    fun record(ms: Int?) {
        total++
        if (ms != null) {
            ok++
            sum += ms
        }
    }

    @Synchronized
    fun avg(): Int? = if (ok == 0) null else (sum / ok).toInt()

    @Synchronized
    fun loss(): Double = if (total == 0) 1.0 else 1.0 - ok.toDouble() / total

    /** Чем меньше, тем лучше: средняя задержка плюс штраф за неудачные попытки. */
    @Synchronized
    fun score(): Double? {
        val a = avg() ?: return null
        return a + loss() * 400.0
    }
}

/**
 * Настоящий замер, как в v2rayN/v2Box: ядро поднимает локальный HTTP-прокси на каждый сервер
 * (порт basePort + номер сервера), и мы делаем HTTPS-запрос через каждый. Задержка измеряется
 * по реальному ответу, поэтому нерабочие серверы с открытым портом отсеиваются.
 */
class RealProbe(
    private val servers: List<Server>,
    private val basePort: Int,
    private val durationMs: Long,
    private val onProgress: (round: Int, remainingMs: Long, stats: List<Stat>) -> Unit,
    private val onDone: (stats: List<Stat>, cancelled: Boolean) -> Unit,
) {
    @Volatile
    private var cancelled = false
    private val stats: List<Stat> = List(servers.size) { Stat() }

    fun cancel() {
        cancelled = true
    }

    fun start() {
        Thread { runProbe() }.apply { isDaemon = true }.start()
    }

    private fun runProbe() {
        val pool = Executors.newFixedThreadPool(40)
        val end = SystemClock.elapsedRealtime() + durationMs
        var round = 0

        while (!cancelled && SystemClock.elapsedRealtime() < end) {
            round++
            val roundStart = SystemClock.elapsedRealtime()

            // сервер, который ни разу не ответил за две попытки, дальше не проверяем
            val targets = ArrayList<Int>()
            for (i in servers.indices) {
                val st = stats[i]
                if (st.ok > 0 || st.total < 2) targets.add(i)
            }
            if (targets.isEmpty()) break

            val latch = CountDownLatch(targets.size)
            for (i in targets) {
                pool.execute {
                    try {
                        stats[i].record(probeOnce(basePort + i))
                    } catch (_: Throwable) {
                    } finally {
                        latch.countDown()
                    }
                }
            }
            val hardStop = SystemClock.elapsedRealtime() + 90_000
            while (!latch.await(500, TimeUnit.MILLISECONDS)) {
                if (cancelled || SystemClock.elapsedRealtime() > hardStop) break
                onProgress(round, maxOf(0L, end - SystemClock.elapsedRealtime()), stats)
            }
            onProgress(round, maxOf(0L, end - SystemClock.elapsedRealtime()), stats)

            // раунды идут не чаще раза в 15 секунд, чтобы не долбить серверы без остановки
            while (!cancelled && SystemClock.elapsedRealtime() < end &&
                SystemClock.elapsedRealtime() < roundStart + 15_000
            ) {
                Thread.sleep(250)
            }
        }
        pool.shutdownNow()
        onDone(stats, cancelled)
    }

    /** Один запрос через сервер. Возвращает задержку в мс или null, если интернета через сервер нет. */
    private fun probeOnce(port: Int): Int? {
        var c: HttpURLConnection? = null
        return try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", port))
            val t0 = System.nanoTime()
            val conn = URL(CHECK_URL).openConnection(proxy) as HttpURLConnection
            c = conn
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.useCaches = false
            conn.instanceFollowRedirects = false
            val code = conn.responseCode
            if (code in 200..399) ((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1) else null
        } catch (e: Throwable) {
            null
        } finally {
            try {
                c?.disconnect()
            } catch (_: Throwable) {
            }
        }
    }

    companion object {
        const val CHECK_URL = "https://cp.cloudflare.com/generate_204"

        fun endpoint(s: Server) = "${s.host}:${s.port}"

        /** Рабочие серверы от лучшего к худшему. Не больше трёх на один адрес, всего не больше [limit]. */
        fun rank(list: List<Server>, st: List<Stat>, limit: Int = 10): List<Server> {
            val scored = ArrayList<Pair<Server, Double>>()
            for (i in list.indices) {
                val s = st[i]
                if (s.ok == 0) continue
                if (s.total >= 3 && s.loss() > 0.5) continue
                val sc = s.score() ?: continue
                scored.add(list[i] to sc)
            }
            scored.sortBy { it.second }
            val perEndpoint = HashMap<String, Int>()
            val result = ArrayList<Server>()
            for (item in scored) {
                val ep = endpoint(item.first)
                val n = perEndpoint[ep] ?: 0
                if (n >= 3) continue
                perEndpoint[ep] = n + 1
                result.add(item.first)
                if (result.size >= limit) break
            }
            return result
        }
    }
}
