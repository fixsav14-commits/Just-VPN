package com.vpnbest.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var servers: List<Server>
    private var skipped = 0
    private var rows: List<Server> = emptyList()
    private val stats = HashMap<String, Stat>() // server.key -> результаты реального замера
    private var selectedKey: String? = null
    private var pendingServer: Server? = null
    private var lastStarted: Server? = null
    private var useFakeIp = true // если ядро не примет FakeIP, переключимся на обычный DNS

    private val handler = Handler(Looper.getMainLooper())

    // замер всех серверов через ядро
    private var probePhase = false // идёт замер (запуск ядра или сами тесты)
    private var probeStarting = false // ждём запуска ядра замера
    private var probeServers: MutableList<Server> = ArrayList()
    private var probeRestarts = 0
    private var probe: RealProbe? = null
    private var afterProbeStop = false // ядро замера остановлено, дальше подбор
    private var pendingRanked: List<Server> = emptyList()

    // автоподбор: пробуем лучшие серверы по очереди, пока не найдём тот, через который идёт интернет
    private var autoMode = false
    private var autoQueue = ArrayDeque<Server>()
    private var autoTotal = 0
    private var awaitingStart = false
    private var pendingCheck = false
    private var nextAfterStop = false
    private var checkToken = 0
    private var checkText: String? = null
    private var checkOk: Boolean? = null
    private var note: String? = null

    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var btnBest: Button
    private lateinit var btnConnect: Button
    private lateinit var adapter: Adapter

    private val prefs by lazy { getSharedPreferences("vpnbest", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)

        val lines = assets.open("servers.txt").bufferedReader().readLines()
        val parsed = ServerParser.parseAll(lines)
        servers = parsed.first
        skipped = parsed.second
        rows = servers
        selectedKey = prefs.getString("selected", null)?.takeIf { k -> servers.any { it.key == k } }
            ?: servers.firstOrNull()?.key

        buildUi()
        refreshUi()

        VpnState.listener = { onVpnState() }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        // если в прошлый раз приложение упало, покажем причину (только когда VPN не работает)
        if (!VpnState.running && !VpnState.connecting) {
            CrashLog.read(this)?.let { showText("В прошлый раз приложение упало", it, false) }
        }
    }

    override fun onDestroy() {
        VpnState.listener = null
        handler.removeCallbacksAndMessages(null)
        probe?.cancel()
        super.onDestroy()
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(8))
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "VPN Best"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.BLACK)
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)

        btnBest = Button(this).apply {
            setOnClickListener { onBestClick() }
        }
        root.addView(btnBest, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        btnConnect = Button(this).apply {
            setOnClickListener { onConnectClick() }
        }
        root.addView(btnConnect, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val btnLog = Button(this).apply {
            text = "Журнал (для диагностики)"
            setOnClickListener { showText("Журнал", AppLog.text().ifEmpty { "Журнал пуст" }, true) }
        }
        root.addView(btnLog, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        info = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(6), 0, dp(6))
        }
        root.addView(info)

        adapter = Adapter()
        val list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            divider = null
            setOnItemClickListener { _, _, pos, _ ->
                if (busy()) return@setOnItemClickListener
                val s = rows[pos]
                selectedKey = s.key
                note = null
                prefs.edit().putString("selected", s.key).apply()
                refreshUi()
            }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    /** Окно с длинным текстом (журнал, причина падения) и кнопкой «Скопировать». */
    private fun showText(title: String, text: String, withClear: Boolean) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.BLACK)
            setTextIsSelectable(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val scroll = ScrollView(this).apply { addView(tv) }
        val b = android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("Скопировать") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("log", text))
                Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Закрыть", null)
        if (withClear) b.setNeutralButton("Очистить") { _, _ -> AppLog.clear() }
        b.show()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun busy() = probePhase || autoMode || afterProbeStop

    private fun selected(): Server? = servers.find { it.key == selectedKey }

    private fun refreshUi() {
        val sel = selected()
        val base = when {
            VpnState.connecting -> "Подключаюсь…"
            VpnState.running -> "Подключено: ${sel?.name ?: ""}"
            VpnState.lastError != null -> "Ошибка: ${VpnState.lastError}"
            else -> "Не подключено"
        }
        val check = checkText
        status.text = if (VpnState.running && check != null) "$base\n$check" else base
        status.setTextColor(
            when {
                VpnState.running && checkOk == false -> Color.rgb(200, 100, 0)
                VpnState.running -> Color.rgb(0, 130, 60)
                VpnState.lastError != null -> Color.rgb(190, 0, 0)
                else -> Color.DKGRAY
            }
        )
        btnBest.text = when {
            probePhase -> "Отмена замера"
            autoMode -> "Отмена проверки"
            else -> "⚡ Лучший сервер (замер 5 минут)"
        }
        btnBest.isEnabled = !afterProbeStop
        btnConnect.isEnabled = !busy() && !VpnState.connecting && sel != null
        btnConnect.text = if (VpnState.running) "Отключить" else "Подключить: ${sel?.name ?: "—"}"
        if (!probePhase) {
            info.text = note ?: ("Серверов: ${servers.size}" +
                (if (skipped > 0) " (ещё $skipped не поддерживаются: транспорт xhttp)" else "") +
                ". Нажмите на сервер, чтобы выбрать его.")
        }
        adapter.notifyDataSetChanged()
    }

    private fun keepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- замер всех серверов ----------

    private fun onBestClick() {
        if (autoMode) {
            AppLog.add("Проверка отменена пользователем")
            endAuto("Проверка отменена")
            if (VpnState.running || VpnState.connecting) stopVpn()
            return
        }
        if (probePhase) {
            cancelProbe()
            return
        }
        startProbePhase()
    }

    private fun startProbePhase() {
        stats.clear()
        note = null
        checkText = null
        checkOk = null
        keepScreenOn(true)
        probePhase = true
        probeServers = ArrayList(servers)
        probeRestarts = 0
        AppLog.add("=== Замер: серверов ${probeServers.size} ===")
        // во время замера обычный VPN должен быть выключен, иначе замер покажет не реальную сеть
        val wasOn = VpnState.running || VpnState.connecting || VpnState.probeReady
        if (wasOn) stopVpn()
        info.text = "Подготовка замера…"
        refreshUi()
        handler.postDelayed({ if (probePhase) launchProbeCore() }, if (wasOn) 2500L else 0L)
    }

    private fun cancelProbe() {
        val p = probe
        if (p != null) {
            p.cancel() // дальше onProbeDone(cancelled = true)
            return
        }
        // ядро замера ещё запускается
        probePhase = false
        probeStarting = false
        keepScreenOn(false)
        stopVpn()
        note = "Замер отменён"
        AppLog.add("Замер отменён до запуска тестов")
        refreshUi()
    }

    private fun finishProbeWithError(msg: String) {
        probePhase = false
        probeStarting = false
        keepScreenOn(false)
        note = msg
        AppLog.add(msg)
        refreshUi()
    }

    private fun launchProbeCore() {
        if (probeServers.isEmpty()) {
            finishProbeWithError("Нет серверов для проверки")
            return
        }
        try {
            val cfg = ConfigBuilder.buildProbe(probeServers, PROBE_PORT)
            val f = File(filesDir, "probe.json")
            f.writeText(cfg)
            probeStarting = true
            VpnState.probeReady = false
            VpnState.probeError = null
            val i = Intent(this, BoxVpnService::class.java)
                .setAction(BoxVpnService.ACTION_PROBE)
                .putExtra(BoxVpnService.EXTRA_CONFIG_PATH, f.path)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            info.text = "Запускаю проверку: ${probeServers.size} серверов…"
        } catch (e: Throwable) {
            finishProbeWithError("Не удалось запустить замер: ${e.message ?: e}")
        }
    }

    private fun onProbeCoreError(err: String) {
        // ядро называет номер сервера с неверными настройками: исключаем его и пробуем снова
        val idx = Regex("""outbounds?\[(\d+)\]""").find(err)?.groupValues?.get(1)?.toIntOrNull()
        if (idx != null && idx in probeServers.indices && probeRestarts < 80) {
            val bad = probeServers.removeAt(idx)
            probeRestarts++
            AppLog.add("Исключён из замера: ${bad.name} (${bad.protocol} ${bad.host}:${bad.port})")
            handler.postDelayed({ if (probePhase) launchProbeCore() }, 800)
        } else {
            finishProbeWithError("Ядро замера не запустилось: $err")
        }
    }

    private fun startProbeTests() {
        val list = ArrayList(probeServers)
        AppLog.add("Тесты запущены, серверов: ${list.size}")
        val p = RealProbe(
            servers = list,
            basePort = PROBE_PORT,
            durationMs = 5 * 60 * 1000L,
            onProgress = { round, remaining, st -> runOnUiThread { onProbeProgress(list, round, remaining, st) } },
            onDone = { st, cancelled -> runOnUiThread { onProbeDone(list, st, cancelled) } },
        )
        probe = p
        p.start()
    }

    private fun applyStats(list: List<Server>, st: List<Stat>) {
        for (i in list.indices) stats[list[i].key] = st[i]
        rows = servers.sortedWith(compareBy<Server> { stats[it.key]?.avg() ?: Int.MAX_VALUE })
        adapter.notifyDataSetChanged()
    }

    private fun onProbeProgress(list: List<Server>, round: Int, remainingMs: Long, st: List<Stat>) {
        if (probe == null) return
        applyStats(list, st)
        val alive = st.count { it.ok > 0 }
        val sec = remainingMs / 1000
        val best = rows.firstOrNull { stats[it.key]?.avg() != null }
        info.text = "Замер: осталось %d:%02d · раунд %d · рабочих серверов: %d из %d".format(
            sec / 60, sec % 60, round, alive, list.size
        ) + (best?.let { "\nСейчас лучший: ${stats[it.key]?.avg()} мс — ${it.name}" } ?: "")
    }

    private fun onProbeDone(list: List<Server>, st: List<Stat>, cancelled: Boolean) {
        probe = null
        applyStats(list, st)
        probePhase = false
        stopVpn() // останавливаем ядро замера
        if (cancelled) {
            keepScreenOn(false)
            note = "Замер отменён"
            AppLog.add("Замер отменён")
            refreshUi()
            return
        }
        val alive = st.count { it.ok > 0 }
        AppLog.add("Замер завершён: рабочих серверов $alive из ${list.size}")
        val ranked = RealProbe.rank(list, st)
        if (ranked.isEmpty()) {
            keepScreenOn(false)
            note = "Ни один сервер не ответил на настоящий запрос. Откройте «Журнал» и пришлите его скриншот."
            refreshUi()
            return
        }
        pendingRanked = ranked
        afterProbeStop = true
        note = "Замер готов: рабочих серверов $alive. Подключаюсь к лучшему…"
        refreshUi()
        // запасной вариант, если сигнал об остановке ядра не придёт
        handler.postDelayed({ proceedAfterProbe() }, 5000)
    }

    private fun proceedAfterProbe() {
        if (!afterProbeStop) return
        afterProbeStop = false
        autoQueue = ArrayDeque(pendingRanked)
        autoTotal = pendingRanked.size
        autoMode = true
        tryNext()
    }

    // ---------- автоподбор рабочего сервера ----------

    private fun tryNext() {
        if (!autoMode) return
        val s = autoQueue.removeFirstOrNull()
        if (s == null) {
            val msg = "Через туннель не прошёл ни один из $autoTotal лучших серверов, хотя замер через ядро их " +
                "видел рабочими. Откройте «Журнал» и пришлите его скриншот."
            AppLog.add(msg)
            endAuto(msg)
            return
        }
        val n = autoTotal - autoQueue.size
        selectedKey = s.key
        prefs.edit().putString("selected", s.key).apply()
        note = "Проверяю сервер $n из $autoTotal: ${s.name}"
        AppLog.add("--- Попытка $n/$autoTotal: ${s.name} (${s.protocol} ${s.host}:${s.port}), замер ${stats[s.key]?.avg()} мс")
        checkText = null
        checkOk = null
        refreshUi()
        connect(s)
    }

    private fun endAuto(msg: String?) {
        autoMode = false
        autoQueue.clear()
        nextAfterStop = false
        keepScreenOn(false)
        if (msg != null) note = msg
        refreshUi()
    }

    // ---------- подключение ----------

    private fun onConnectClick() {
        if (VpnState.running) {
            stopVpn()
            return
        }
        note = null
        selected()?.let {
            AppLog.add("--- Ручное подключение: ${it.name} (${it.protocol} ${it.host}:${it.port})")
            connect(it)
        }
    }

    private fun connect(server: Server) {
        val prep = VpnService.prepare(this)
        if (prep != null) {
            pendingServer = server
            startActivityForResult(prep, REQ_VPN)
        } else {
            startVpn(server)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            val s = pendingServer
            pendingServer = null
            if (resultCode == RESULT_OK && s != null) {
                startVpn(s)
            } else {
                Toast.makeText(this, "Нужно разрешение на VPN", Toast.LENGTH_LONG).show()
                endAuto("Без разрешения на VPN подключиться нельзя")
            }
        }
    }

    private fun startVpn(server: Server) {
        lastStarted = server
        pendingCheck = true
        awaitingStart = true
        VpnState.update(running = false, connecting = true)
        // имя сервера превращаем в адрес до включения VPN (в фоне: сеть в главном потоке запрещена)
        val fake = useFakeIp
        thread(isDaemon = true) {
            val ip = ConfigBuilder.resolveIpv4(server.host)
            if (ip != null) AppLog.add("адрес сервера ${server.host} → $ip")
            else if (server.host.any { it.isLetter() }) AppLog.add("адрес сервера ${server.host} определить не удалось, ядро попробует само")
            runOnUiThread { launchVpnService(server, fake, ip) }
        }
    }

    private fun launchVpnService(server: Server, fakeIp: Boolean, ip: String?) {
        try {
            val cfg = ConfigBuilder.build(server, fakeIp, ip)
            val i = Intent(this, BoxVpnService::class.java)
                .setAction(BoxVpnService.ACTION_START)
                .putExtra(BoxVpnService.EXTRA_CONFIG, cfg)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Throwable) {
            pendingCheck = false
            awaitingStart = false
            AppLog.add("Не удалось запустить VPN: ${e.message ?: e}")
            endAuto(null)
            VpnState.update(running = false, connecting = false, error = e.message ?: e.toString())
        }
    }

    private fun stopVpn() {
        try {
            startService(Intent(this, BoxVpnService::class.java).setAction(BoxVpnService.ACTION_STOP))
        } catch (_: Throwable) {
        }
    }

    /** Вызывается при любом изменении состояния VPN или ядра замера (в главном потоке). */
    private fun onVpnState() {
        refreshUi()

        if (probeStarting) {
            if (VpnState.probeReady) {
                probeStarting = false
                startProbeTests()
            } else {
                val err = VpnState.probeError
                if (err != null) {
                    probeStarting = false
                    onProbeCoreError(err)
                }
            }
            return
        }

        if (VpnState.running) {
            awaitingStart = false
            if (pendingCheck) {
                pendingCheck = false
                runCheck()
            }
        } else if (!VpnState.connecting) {
            pendingCheck = false
            checkToken++ // результаты старых проверок больше не нужны
            checkText = null
            checkOk = null
            if (afterProbeStop) {
                handler.postDelayed({ proceedAfterProbe() }, 1000)
            } else if (nextAfterStop) {
                nextAfterStop = false
                handler.postDelayed({ tryNext() }, 1000)
            } else if (awaitingStart) {
                awaitingStart = false
                val err = VpnState.lastError
                val srv = lastStarted
                if (useFakeIp && srv != null && err != null && err.contains("fakeip", ignoreCase = true)) {
                    useFakeIp = false
                    AppLog.add("Ядро не приняло FakeIP, пробую обычный DNS")
                    handler.postDelayed({ startVpn(srv) }, 800)
                } else if (autoMode) {
                    // сервер не запустился (например, неверные настройки): идём к следующему
                    AppLog.add("Сервер не запустился: ${VpnState.lastError}")
                    handler.postDelayed({ tryNext() }, 500)
                }
            }
        }
    }

    // ---------- проверка интернета через VPN ----------

    private class Leg {
        @Volatile var ms = -1L
        @Volatile var err: String? = null
        fun text(): String = if (ms >= 0) "ок $ms мс" else (err ?: "нет ответа")
    }

    private fun errText(e: Throwable): String =
        e.javaClass.simpleName + (e.message?.let { ": " + it.take(80) } ?: "")

    private fun runCheck() {
        val token = ++checkToken
        checkText = "Проверяю интернет…"
        checkOk = null
        refreshUi()
        thread(isDaemon = true) {
            // Приложение исключено из туннеля, поэтому проверяем через локальный вход ядра VPN
            // (127.0.0.1:CHECK_PORT): запрос идёт ровно тем маршрутом и тем сервером, что и VPN.
            try {
                Thread.sleep(1200)
            } catch (_: InterruptedException) {
            }
            val ip = Leg()
            val https = Leg()
            val workers = ArrayList<Thread>()

            // 1) HTTPS по IP-адресу, без DNS
            workers.add(thread(isDaemon = true) { viaCore("https://1.1.1.1/cdn-cgi/trace", ip) })
            // 2) настоящий HTTPS-запрос к сайту по имени (имя разрешает сам сервер)
            workers.add(thread(isDaemon = true) { viaCore(RealProbe.CHECK_URL, https) })

            val deadline = System.currentTimeMillis() + 15000
            for (w in workers) {
                val left = deadline - System.currentTimeMillis()
                if (left > 0) w.join(left)
            }
            val detail = "по IP 1.1.1.1: ${ip.text()}; по имени cp.cloudflare.com: ${https.text()}"
            AppLog.add("Проверка интернета: $detail")
            runOnUiThread { onCheckResult(token, https.ms, detail) }
        }
    }

    /** Один HTTPS-запрос через локальный вход ядра VPN. */
    private fun viaCore(url: String, leg: Leg) {
        val t0 = System.nanoTime()
        try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", ConfigBuilder.CHECK_PORT))
            val c = URL(url).openConnection(proxy) as HttpURLConnection
            c.connectTimeout = 12000
            c.readTimeout = 12000
            c.instanceFollowRedirects = false
            c.useCaches = false
            val code = c.responseCode
            c.disconnect()
            if (code in 200..399) leg.ms = (System.nanoTime() - t0) / 1_000_000
            else leg.err = "код $code"
        } catch (e: Throwable) {
            leg.err = errText(e)
        }
    }

    private fun onCheckResult(token: Int, ms: Long, detail: String) {
        if (token != checkToken || !VpnState.running) return
        if (ms >= 0) {
            checkOk = true
            checkText = "Сервер пропускает трафик ($ms мс). Откройте браузер или Telegram, чтобы убедиться."
            if (autoMode) endAuto("Готово: этот сервер пропускает трафик.") else refreshUi()
        } else if (autoMode) {
            checkOk = false
            checkText = "Интернета через этот сервер нет"
            refreshUi()
            nextAfterStop = true
            stopVpn()
        } else {
            checkOk = false
            checkText = "Подключено, но проверка не прошла.\n$detail"
            refreshUi()
        }
    }

    // ---------- список ----------

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int) = rows[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val s = rows[position]
            val box = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                addView(TextView(context).apply { textSize = 15f; setTextColor(Color.BLACK) })
                addView(TextView(context).apply { textSize = 12f; setTextColor(Color.GRAY) })
            }
            val title = box.getChildAt(0) as TextView
            val sub = box.getChildAt(1) as TextView
            val st = stats[s.key]
            val avg = st?.avg()
            val pingText = when {
                st == null -> "—"
                avg != null -> "$avg мс"
                else -> "✗"
            }
            title.text = "$pingText   ${s.name}"
            sub.text = "${s.protocol.uppercase()} · ${RealProbe.endpoint(s)}" +
                if (s.insecure) " · ⚠ без проверки сертификата" else ""
            box.setBackgroundColor(if (s.key == selectedKey) Color.rgb(220, 238, 255) else Color.TRANSPARENT)
            box.gravity = Gravity.CENTER_VERTICAL
            return box
        }
    }

    companion object {
        private const val REQ_VPN = 100
        private const val PROBE_PORT = 31000
    }
}
