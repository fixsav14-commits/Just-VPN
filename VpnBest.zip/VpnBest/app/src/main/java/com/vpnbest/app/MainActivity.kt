package com.vpnbest.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var servers: List<Server>
    private var skipped = 0
    private var rows: List<Server> = emptyList()
    private val pings = HashMap<String, Int?>() // endpoint -> средний пинг
    private var selectedKey: String? = null
    private var search: BestSearch? = null
    private var pendingServer: Server? = null

    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var btnBest: Button
    private lateinit var btnConnect: Button
    private lateinit var adapter: Adapter

    private val prefs by lazy { getSharedPreferences("vpnbest", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val lines = assets.open("servers.txt").bufferedReader().readLines()
        val parsed = ServerParser.parseAll(lines)
        servers = parsed.first
        skipped = parsed.second
        rows = servers
        selectedKey = prefs.getString("selected", null)?.takeIf { k -> servers.any { it.key == k } }
            ?: servers.firstOrNull()?.key

        buildUi()
        refreshUi()

        VpnState.listener = { refreshUi() }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
    }

    override fun onDestroy() {
        VpnState.listener = null
        search?.cancel()
        super.onDestroy()
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(8))
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "VPN Best"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.BLACK)
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)

        btnBest = Button(this).apply {
            setOnClickListener { onBestClick() }
        }
        root.addView(btnBest, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        btnConnect = Button(this).apply {
            setOnClickListener { onConnectClick() }
        }
        root.addView(btnConnect, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        info = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(6), 0, dp(6))
        }
        root.addView(info)

        adapter = Adapter()
        val list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            divider = null
            setOnItemClickListener { _, _, pos, _ ->
                if (search != null) return@setOnItemClickListener
                val s = rows[pos]
                selectedKey = s.key
                prefs.edit().putString("selected", s.key).apply()
                refreshUi()
            }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun selected(): Server? = servers.find { it.key == selectedKey }

    private fun refreshUi() {
        val sel = selected()
        val searching = search != null
        status.text = when {
            VpnState.connecting -> "Подключаюсь…"
            VpnState.running -> "Подключено: ${sel?.name ?: ""}"
            VpnState.lastError != null -> "Ошибка: ${VpnState.lastError}"
            else -> "Не подключено"
        }
        status.setTextColor(
            when {
                VpnState.running -> Color.rgb(0, 130, 60)
                VpnState.lastError != null -> Color.rgb(190, 0, 0)
                else -> Color.DKGRAY
            }
        )
        btnBest.text = if (searching) "Отмена замера" else "⚡ Лучший сервер (замер 5 минут)"
        btnConnect.isEnabled = !searching && !VpnState.connecting && sel != null
        btnConnect.text = if (VpnState.running) "Отключить" else "Подключить: ${sel?.name ?: "—"}"
        if (!searching) {
            info.text = "Серверов: ${servers.size}" +
                (if (skipped > 0) " (ещё $skipped не поддерживаются: транспорт xhttp)" else "") +
                ". Нажмите на сервер, чтобы выбрать его."
        }
        adapter.notifyDataSetChanged()
    }

    // ---------- действия ----------

    private fun onBestClick() {
        val running = search
        if (running != null) {
            running.cancel()
            return
        }
        pings.clear()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val s = BestSearch(
            servers = servers,
            durationMs = 5 * 60 * 1000L,
            onProgress = { round, remaining, stats -> runOnUiThread { onProgress(round, remaining, stats) } },
            onDone = { best, stats, cancelled -> runOnUiThread { onDone(best, stats, cancelled) } },
        )
        search = s
        refreshUi()
        s.start()
    }

    private fun onProgress(round: Int, remainingMs: Long, stats: Map<String, Stat>) {
        if (search == null) return
        applyStats(stats)
        val sec = remainingMs / 1000
        val best = rows.firstOrNull { pings[BestSearch.endpoint(it)] != null }
        info.text = "Замер: осталось %d:%02d · раунд %d".format(sec / 60, sec % 60, round) +
            (best?.let { "\nСейчас лучший: ${pings[BestSearch.endpoint(it)]} мс — ${it.name}" } ?: "")
    }

    private fun applyStats(stats: Map<String, Stat>) {
        for ((ep, st) in stats) pings[ep] = st.avg()
        rows = servers.sortedWith(compareBy<Server> { pings[BestSearch.endpoint(it)] ?: Int.MAX_VALUE })
        adapter.notifyDataSetChanged()
    }

    private fun onDone(best: Server?, stats: Map<String, Stat>, cancelled: Boolean) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        search = null
        applyStats(stats)
        if (cancelled) {
            info.text = "Замер отменён"
            refreshUi()
            return
        }
        if (best == null) {
            Toast.makeText(this, "Ни один сервер не ответил", Toast.LENGTH_LONG).show()
            info.text = "Ни один сервер не ответил на пинг"
            refreshUi()
            return
        }
        selectedKey = best.key
        prefs.edit().putString("selected", best.key).apply()
        info.text = "Лучший: ${pings[BestSearch.endpoint(best)]} мс — ${best.name}"
        refreshUi()
        connect(best)
    }

    private fun onConnectClick() {
        if (VpnState.running) {
            startService(Intent(this, BoxVpnService::class.java).setAction(BoxVpnService.ACTION_STOP))
            return
        }
        selected()?.let { connect(it) }
    }

    private fun connect(server: Server) {
        val prep = VpnService.prepare(this)
        if (prep != null) {
            pendingServer = server
            startActivityForResult(prep, REQ_VPN)
        } else {
            startVpn(server)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            val s = pendingServer
            pendingServer = null
            if (resultCode == RESULT_OK && s != null) startVpn(s)
            else Toast.makeText(this, "Нужно разрешение на VPN", Toast.LENGTH_LONG).show()
        }
    }

    private fun startVpn(server: Server) {
        val cfg = ConfigBuilder.build(server)
        val i = Intent(this, BoxVpnService::class.java)
            .setAction(BoxVpnService.ACTION_START)
            .putExtra(BoxVpnService.EXTRA_CONFIG, cfg)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        VpnState.update(running = false, connecting = true)
    }

    // ---------- список ----------

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int) = rows[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val s = rows[position]
            val box = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                addView(TextView(context).apply { textSize = 15f; setTextColor(Color.BLACK) })
                addView(TextView(context).apply { textSize = 12f; setTextColor(Color.GRAY) })
            }
            val title = box.getChildAt(0) as TextView
            val sub = box.getChildAt(1) as TextView
            val ep = BestSearch.endpoint(s)
            val pingText = when {
                !s.tcp -> "UDP"
                pings[ep] != null -> "${pings[ep]} мс"
                else -> "—"
            }
            title.text = "$pingText   ${s.name}"
            sub.text = "${s.protocol.uppercase()} · $ep" + if (s.insecure) " · ⚠ без проверки сертификата" else ""
            box.setBackgroundColor(if (s.key == selectedKey) Color.rgb(220, 238, 255) else Color.TRANSPARENT)
            box.gravity = Gravity.CENTER_VERTICAL
            return box
        }
    }

    companion object {
        private const val REQ_VPN = 100
    }
}
