package com.vpnbest.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private var servers: List<Server> = emptyList()
    private var skipped = 0
    private var listBusy = false // идёт скачивание списка
    private var listNote = "встроенный список"
    private var rows: List<Server> = emptyList()
    private val stats = HashMap<String, Stat>() // server.key -> результаты замера
    private var selectedKey: String? = null
    private var pendingServer: Server? = null
    private var lastStarted: Server? = null
    private var useFakeIp = true // если ядро не примет FakeIP, переключимся на обычный DNS
    private var filter = 0 // 0 — все, 1 — BL, 2 — CIDR

    private val handler = Handler(Looper.getMainLooper())

    // замер всех серверов через ядро
    private var probePhase = false // идёт замер (подготовка, запуск ядра или сами тесты)
    private var probeAutoConnect = true // после замера подключиться к лучшему
    private var probeStarting = false // ждём запуска ядра замера
    private var probeT0 = 0L
    private var prepToken = 0
    private var probeAll: List<Server> = emptyList() // всё, что проверяли, до отсева по TCP
    private var probeServers: MutableList<Server> = ArrayList()
    private var probePins: Map<String, String> = emptyMap()
    private var probeUnreachable: Set<String> = emptySet()
    private var probeRestarts = 0
    private var probe: RealProbe? = null
    private var afterProbeStop = false // ядро замера остановлено, дальше подбор
    private var pendingRanked: List<Server> = emptyList()

    // автоподбор: пробуем лучшие серверы по очереди, пока не найдём тот, через который идёт интернет
    private var autoMode = false
    private var autoQueue = ArrayDeque<Server>()
    private var autoTotal = 0
    private var awaitingStart = false
    private var pendingCheck = false
    private var nextAfterStop = false
    private var checkToken = 0
    private var checkText: String? = null
    private var checkOk: Boolean? = null
    private var note: String? = null

    private lateinit var status: TextView
    private lateinit var statusSub: TextView
    private lateinit var info: TextView
    private lateinit var groupTitle: TextView
    private lateinit var filterView: TextView
    private lateinit var btnPing: TextView
    private lateinit var btnUpdate: TextView
    private lateinit var btnBest: Button
    private lateinit var btnConnect: Button
    private lateinit var adapter: Adapter

    private val prefs by lazy { getSharedPreferences("vpnbest", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)

        listNote = prefs.getString("list_note", null) ?: "встроенный список"
        val parsed = ServerParser.parseAll(ListStore.load(this))
        servers = parsed.first
        skipped = parsed.second
        rebuildRows()
        selectedKey = prefs.getString("selected", null)?.takeIf { k -> servers.any { it.key == k } }
            ?: servers.firstOrNull()?.key

        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildUi()
        refreshUi()

        VpnState.listener = { onVpnState() }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        // если в прошлый раз приложение упало, покажем причину (только когда VPN не работает)
        if (!VpnState.running && !VpnState.connecting) {
            CrashLog.read(this)?.let { showText("В прошлый раз приложение упало", it, false) }
        }
    }

    override fun onResume() {
        super.onResume()
        // списки в интернете меняются каждый час: если наш старше получаса, тихо обновляем
        val now = System.currentTimeMillis()
        val age = now - prefs.getLong("list_time", 0L)
        val sinceTry = now - prefs.getLong("list_try", 0L) // не мучаем сеть, если недавно уже пробовали
        if (!listBusy && !busy() && !VpnState.connecting && pendingServer == null && !awaitingStart &&
            (age > 30 * 60_000L || age < 0) && (sinceTry > 10 * 60_000L || sinceTry < 0)
        ) refreshList(false)
    }

    override fun onDestroy() {
        VpnState.listener = null
        handler.removeCallbacksAndMessages(null)
        probe?.cancel()
        super.onDestroy()
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    private fun button(text: String, bg: Int, fg: Int): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 16f
        setTextColor(fg)
        background = shape(bg, 26)
        stateListAnimator = null
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        // заголовок
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(6))
        }
        head.addView(TextView(this).apply {
            text = "Конфигурации"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(this).apply {
            text = "Журнал"
            textSize = 15f
            setTextColor(ACCENT)
            setPadding(dp(10), dp(8), 0, dp(8))
            setOnClickListener { showText("Журнал", AppLog.text().ifEmpty { "Журнал пуст" }, true) }
        })
        root.addView(head)

        // главная кнопка
        btnBest = button("", ACCENT, Color.BLACK).apply {
            setTypeface(null, Typeface.BOLD)
            setOnClickListener { onBestClick() }
        }
        root.addView(btnBest, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply {
            setMargins(dp(16), dp(8), dp(16), dp(6))
        })

        // фильтр и «Пинг всех»
        val ctl = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(6), dp(20), dp(6))
        }
        filterView = TextView(this).apply {
            textSize = 16f
            setTextColor(GRAY)
            setPadding(0, dp(8), dp(12), dp(8))
            setOnClickListener {
                if (busy()) return@setOnClickListener
                filter = (filter + 1) % FILTERS.size
                rebuildRows()
                refreshUi()
            }
        }
        ctl.addView(filterView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        btnUpdate = TextView(this).apply {
            textSize = 16f
            setTextColor(ACCENT)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { onUpdateClick() }
            // долгое нажатие: меню (добавить свои ссылки, вернуть встроенный список)
            setOnLongClickListener {
                showListMenu(null)
                true
            }
        }
        ctl.addView(btnUpdate)
        btnPing = TextView(this).apply {
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ACCENT)
            setPadding(dp(12), dp(8), 0, dp(8))
            setOnClickListener { onPingClick() }
        }
        ctl.addView(btnPing)
        root.addView(ctl)

        // карточка группы
        val group = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 16)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        groupTitle = TextView(this).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
        }
        group.addView(groupTitle)
        info = TextView(this).apply {
            textSize = 13f
            setTextColor(GRAY)
            setPadding(0, dp(4), 0, 0)
        }
        group.addView(info)
        root.addView(group, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(10), dp(4), dp(10), dp(4))
        })

        // список серверов
        adapter = Adapter()
        val list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            divider = null
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, pos, _ ->
                if (busy()) return@setOnItemClickListener
                val s = rows[pos]
                selectedKey = s.key
                note = null
                prefs.edit().putString("selected", s.key).apply()
                refreshUi()
            }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // нижняя панель
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val r = dp(24).toFloat()
            background = GradientDrawable().apply {
                setColor(PANEL)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            setPadding(dp(20), dp(14), dp(16), dp(14))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.WHITE)
        }
        statusSub = TextView(this).apply {
            textSize = 12f
            setTextColor(GRAY)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
        }
        texts.addView(status)
        texts.addView(statusSub)
        panel.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        btnConnect = button("", Color.rgb(84, 84, 88), Color.WHITE).apply {
            setPadding(dp(22), 0, dp(22), 0)
            setOnClickListener { onConnectClick() }
        }
        panel.addView(btnConnect, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)))
        root.addView(panel)

        setContentView(root)
    }

    /** Окно с длинным текстом (журнал, причина падения) и кнопкой «Скопировать». */
    private fun showText(title: String, text: String, withClear: Boolean) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val scroll = ScrollView(this).apply { addView(tv) }
        val b = android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("Скопировать") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("log", text))
                Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Закрыть", null)
        if (withClear) b.setNeutralButton("Очистить") { _, _ -> AppLog.clear() }
        b.show()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun busy() = probePhase || autoMode || afterProbeStop

    private fun selected(): Server? = servers.find { it.key == selectedKey }

    private fun tagOf(s: Server): String = when {
        s.group == "BL" || s.group == "CIDR" -> s.group
        s.name.contains("CIDR", true) -> "CIDR"
        s.name.contains("[BL]") -> "BL"
        else -> ""
    }

    private fun visible(): List<Server> = when (filter) {
        1 -> servers.filter { tagOf(it) == "BL" }
        2 -> servers.filter { tagOf(it) == "CIDR" }
        else -> servers
    }

    private fun rebuildRows() {
        rows = visible().sortedWith(compareBy<Server> { stats[it.key]?.avg() ?: Int.MAX_VALUE })
    }

    private fun refreshUi() {
        val sel = selected()
        status.text = when {
            VpnState.connecting -> "Подключаюсь…"
            VpnState.running -> "Подключено"
            VpnState.lastError != null -> "Ошибка"
            else -> "Не подключено"
        }
        status.setTextColor(
            when {
                VpnState.running && checkOk == false -> Color.rgb(255, 170, 60)
                VpnState.running -> Color.rgb(120, 220, 140)
                VpnState.lastError != null -> Color.rgb(255, 107, 107)
                else -> Color.WHITE
            }
        )
        val check = checkText
        statusSub.text = when {
            VpnState.running -> (sel ?: lastStarted)?.name.orEmpty() + (if (check != null) "\n$check" else "")
            VpnState.lastError != null && !VpnState.connecting -> VpnState.lastError ?: ""
            else -> sel?.name ?: ""
        }

        btnBest.text = when {
            probePhase -> "Отмена замера"
            autoMode -> "Отмена проверки"
            else -> "⚡ Лучший сервер (замер 1 минута)"
        }
        btnBest.isEnabled = !afterProbeStop
        btnPing.text = if (probePhase) "Отмена" else "Пинг всех"
        btnPing.alpha = if (autoMode || afterProbeStop) 0.35f else 1f
        btnUpdate.text = if (listBusy) "Обновляю…" else "Обновить"
        btnUpdate.alpha = if (busy() || listBusy) 0.4f else 1f
        filterView.text = "≡  ${FILTERS[filter]} ▾"
        filterView.alpha = if (busy()) 0.5f else 1f

        btnConnect.isEnabled = !busy() && !VpnState.connecting && (sel != null || VpnState.running)
        btnConnect.alpha = if (btnConnect.isEnabled) 1f else 0.45f
        btnConnect.text = if (VpnState.running) "Отключить" else "Подключить"

        groupTitle.text = "Local (${rows.size})"
        if (!probePhase) {
            info.text = note ?: ("Серверов: ${servers.size}, $listNote" +
                (if (skipped > 0) " (ещё $skipped не поддерживаются: транспорт xhttp)" else "") +
                ". Нажмите на сервер, чтобы выбрать его.")
        }
        adapter.notifyDataSetChanged()
    }

    private fun keepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- замер всех серверов ----------

    private fun onBestClick() {
        if (autoMode) {
            AppLog.add("Проверка отменена пользователем")
            endAuto("Проверка отменена")
            if (VpnState.running || VpnState.connecting) stopVpn()
            return
        }
        if (probePhase) {
            cancelProbe()
            return
        }
        startProbePhase(true)
    }

    private fun onPingClick() {
        if (autoMode || afterProbeStop) return
        if (probePhase) {
            cancelProbe()
            return
        }
        startProbePhase(false)
    }

    private fun startProbePhase(autoConnect: Boolean) {
        stats.clear()
        note = null
        checkText = null
        checkOk = null
        keepScreenOn(true)
        probePhase = true
        probeAutoConnect = autoConnect
        probeT0 = SystemClock.elapsedRealtime()
        probeAll = ArrayList(visible())
        probeServers = ArrayList(probeAll)
        probeUnreachable = emptySet()
        probePins = emptyMap()
        probeRestarts = 0
        rebuildRows()
        AppLog.add("=== Замер (${FILTERS[filter]}): серверов ${probeAll.size}, режим: " +
            (if (autoConnect) "лучший сервер" else "только пинг") + " ===")
        // во время замера обычный VPN должен быть выключен, иначе замер покажет не реальную сеть
        val wasOn = VpnState.running || VpnState.connecting || VpnState.probeReady
        if (wasOn) stopVpn()
        info.text = "Подготовка замера…"
        refreshUi()
        handler.postDelayed({ if (probePhase) runPrep() }, if (wasOn) 2500L else 0L)
    }

    /** Быстрая проверка до замера: узнаём адреса и смотрим, до каких серверов вообще можно дойти. */
    private fun runPrep() {
        val token = ++prepToken
        val list = ArrayList(probeAll)
        info.text = "Проверяю адреса и доступность ${list.size} серверов…"
        thread(isDaemon = true) {
            val r = try {
                Prep.run(list) { token != prepToken || !probePhase }
            } catch (e: Throwable) {
                AppLog.add("Предпроверка не удалась: ${e.message ?: e}")
                PrepResult(emptyMap(), emptyMap(), emptyMap())
            }
            runOnUiThread { if (token == prepToken && probePhase) onPrepDone(list, r) }
        }
    }

    private fun onPrepDone(list: List<Server>, r: PrepResult) {
        probePins = r.pins
        probeUnreachable = r.unreachable.keys
        val keep = ArrayList<Server>()
        for (s in list) {
            val why = r.unreachable[s.key]
            if (why != null) {
                stats[s.key] = Stat().apply {
                    record(null)
                    record(null)
                    reason = why
                }
            } else {
                keep.add(s)
            }
        }
        probeServers = keep
        rebuildRows()
        adapter.notifyDataSetChanged()
        if (keep.isEmpty()) {
            finishProbeWithError(
                "До серверов не дойти ни по одному адресу: тайм-аут или отказ. " +
                    "Проверьте интернет и попробуйте другую сеть."
            )
            return
        }
        launchProbeCore()
    }

    private fun cancelProbe() {
        val p = probe
        if (p != null) {
            p.cancel() // дальше onProbeDone(cancelled = true)
            return
        }
        // идёт подготовка или ядро ещё запускается
        prepToken++
        probePhase = false
        probeStarting = false
        keepScreenOn(false)
        stopVpn()
        note = "Замер отменён"
        AppLog.add("Замер отменён до запуска тестов")
        refreshUi()
    }

    private fun finishProbeWithError(msg: String) {
        probePhase = false
        probeStarting = false
        keepScreenOn(false)
        note = msg
        AppLog.add(msg)
        refreshUi()
    }

    private fun launchProbeCore() {
        if (probeServers.isEmpty()) {
            finishProbeWithError("Нет серверов для проверки")
            return
        }
        try {
            val cfg = ConfigBuilder.buildProbe(probeServers, PROBE_PORT, probePins)
            val f = File(filesDir, "probe.json")
            f.writeText(cfg)
            probeStarting = true
            VpnState.probeReady = false
            VpnState.probeError = null
            val i = Intent(this, BoxVpnService::class.java)
                .setAction(BoxVpnService.ACTION_PROBE)
                .putExtra(BoxVpnService.EXTRA_CONFIG_PATH, f.path)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            info.text = "Запускаю проверку: ${probeServers.size} серверов…"
        } catch (e: Throwable) {
            finishProbeWithError("Не удалось запустить замер: ${e.message ?: e}")
        }
    }

    private fun onProbeCoreError(err: String) {
        // ядро называет номер сервера с неверными настройками: исключаем его и пробуем снова
        val idx = Regex("""outbounds?\[(\d+)\]""").find(err)?.groupValues?.get(1)?.toIntOrNull()
        if (idx != null && idx in probeServers.indices && probeRestarts < 80) {
            val bad = probeServers.removeAt(idx)
            probeRestarts++
            AppLog.add("Исключён из замера: ${bad.name} (${bad.protocol} ${bad.host}:${bad.port})")
            handler.postDelayed({ if (probePhase) launchProbeCore() }, 800)
        } else {
            finishProbeWithError("Ядро замера не запустилось: $err")
        }
    }

    private fun startProbeTests() {
        val list = ArrayList(probeServers)
        val elapsed = SystemClock.elapsedRealtime() - probeT0
        // весь замер, вместе с подготовкой, укладываем в минуту (но на сами тесты даём не меньше 20 секунд)
        val duration = maxOf(20_000L, PROBE_TOTAL_MS - elapsed)
        AppLog.add("Тесты запущены, серверов: ${list.size}, времени: ${duration / 1000} с")
        val p = RealProbe(
            servers = list,
            basePort = PROBE_PORT,
            durationMs = duration,
            onProgress = { round, remaining, st -> runOnUiThread { onProbeProgress(list, round, remaining, st) } },
            onDone = { st, cancelled -> runOnUiThread { onProbeDone(list, st, cancelled) } },
        )
        probe = p
        p.start()
    }

    private fun applyStats(list: List<Server>, st: List<Stat>) {
        for (i in list.indices) stats[list[i].key] = st[i]
        rebuildRows()
        adapter.notifyDataSetChanged()
    }

    private fun onProbeProgress(list: List<Server>, round: Int, remainingMs: Long, st: List<Stat>) {
        if (probe == null) return
        applyStats(list, st)
        val alive = st.count { it.ok > 0 }
        val sec = remainingMs / 1000
        val best = rows.firstOrNull { stats[it.key]?.avg() != null }
        info.text = "Замер: осталось 0:%02d · рабочих: %d из %d (недоступно по TCP: %d)".format(
            sec, alive, list.size, probeAll.size - list.size
        ) + (best?.let { "\nСейчас лучший: ${stats[it.key]?.avg()} мс — ${it.name}" } ?: "")
    }

    private fun onProbeDone(list: List<Server>, st: List<Stat>, cancelled: Boolean) {
        probe = null
        applyStats(list, st)
        probePhase = false
        stopVpn() // останавливаем ядро замера
        if (cancelled) {
            keepScreenOn(false)
            note = "Замер отменён"
            AppLog.add("Замер отменён")
            refreshUi()
            return
        }
        val alive = st.count { it.ok > 0 }
        AppLog.add("Замер завершён: рабочих серверов $alive из ${list.size} " +
            "(ещё ${probeAll.size - list.size} отсеяно до замера: до них не дойти по TCP)")
        logReport()
        if (!probeAutoConnect) {
            keepScreenOn(false)
            note = if (alive > 0) "Замер готов: рабочих серверов $alive из ${probeAll.size}. Лучшие — вверху списка."
            else "Рабочих серверов нет: все ${probeAll.size} не отвечают с вашей сети."
            refreshUi()
            return
        }
        val ranked = RealProbe.rank(list, st)
        if (ranked.isEmpty()) {
            keepScreenOn(false)
            note = "Ни один сервер не ответил на настоящий запрос. Скорее всего, с вашей сети они недоступны " +
                "(в v2Box те же серверы дают «Тайм-аут»). Нажмите «Обновить» (список в интернете меняется каждый час) или попробуйте другую сеть."
            refreshUi()
            return
        }
        pendingRanked = ranked
        afterProbeStop = true
        note = "Замер готов: рабочих серверов $alive. Подключаюсь к лучшему…"
        refreshUi()
        // запасной вариант, если сигнал об остановке ядра не придёт
        handler.postDelayed({ proceedAfterProbe() }, 5000)
    }

    /** Итог замера в журнал: по группам BL/CIDR и протоколам, и серверы, до которых дошли, но запрос не прошёл. */
    private fun logReport() {
        fun line(title: String, group: List<Server>) {
            if (group.isEmpty()) return
            val reach = group.count { it.key !in probeUnreachable }
            val ok = group.count { stats[it.key]?.avg() != null }
            AppLog.add("Итог $title: всего ${group.size}, дошли ${reach}, запрос прошёл $ok")
        }
        for (g in listOf("BL", "CIDR", "")) line(if (g.isEmpty()) "прочие" else g, probeAll.filter { tagOf(it) == g })
        for (p in probeAll.map { it.protocol }.distinct()) line(p, probeAll.filter { it.protocol == p })

        val reachedButFailed = probeAll.filter {
            it.key !in probeUnreachable && stats[it.key]?.let { s -> s.avg() == null } == true
        }
        if (reachedButFailed.isNotEmpty()) {
            AppLog.add("Дошли до сервера, но запрос не прошёл (${reachedButFailed.size}):")
            for (s in reachedButFailed.take(40)) {
                AppLog.add("  ${s.protocol} ${s.host}:${s.port} ${tagOf(s)} — ${stats[s.key]?.reason ?: "?"}")
            }
        }
        val good = probeAll.filter { stats[it.key]?.avg() != null }.sortedBy { stats[it.key]?.avg() }
        if (good.isNotEmpty()) {
            AppLog.add("Рабочие серверы:")
            for (s in good.take(20)) {
                AppLog.add("  ${stats[s.key]?.avg()} мс  ${s.protocol} ${s.host}:${s.port} ${tagOf(s)}")
            }
        }
    }

    private fun proceedAfterProbe() {
        if (!afterProbeStop) return
        afterProbeStop = false
        autoQueue = ArrayDeque(pendingRanked)
        autoTotal = pendingRanked.size
        autoMode = true
        tryNext()
    }

    // ---------- автоподбор рабочего сервера ----------

    private fun tryNext() {
        if (!autoMode) return
        val s = autoQueue.removeFirstOrNull()
        if (s == null) {
            val msg = "Через туннель не прошёл ни один из $autoTotal лучших серверов, хотя замер через ядро их " +
                "видел рабочими. Откройте «Журнал» и пришлите его."
            AppLog.add(msg)
            endAuto(msg)
            return
        }
        val n = autoTotal - autoQueue.size
        selectedKey = s.key
        prefs.edit().putString("selected", s.key).apply()
        note = "Проверяю сервер $n из $autoTotal: ${s.name}"
        AppLog.add("--- Попытка $n/$autoTotal: ${s.name} (${s.protocol} ${s.host}:${s.port}), замер ${stats[s.key]?.avg()} мс")
        checkText = null
        checkOk = null
        refreshUi()
        connect(s)
    }

    private fun endAuto(msg: String?) {
        autoMode = false
        autoQueue.clear()
        nextAfterStop = false
        keepScreenOn(false)
        if (msg != null) note = msg
        refreshUi()
    }

    // ---------- подключение ----------

    private fun onConnectClick() {
        if (VpnState.running) {
            stopVpn()
            return
        }
        note = null
        selected()?.let {
            AppLog.add("--- Ручное подключение: ${it.name} (${it.protocol} ${it.host}:${it.port})")
            connect(it)
        }
    }

    private fun connect(server: Server) {
        val prep = VpnService.prepare(this)
        if (prep != null) {
            pendingServer = server
            startActivityForResult(prep, REQ_VPN)
        } else {
            startVpn(server)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            val s = pendingServer
            pendingServer = null
            if (resultCode == RESULT_OK && s != null) {
                startVpn(s)
            } else {
                Toast.makeText(this, "Нужно разрешение на VPN", Toast.LENGTH_LONG).show()
                endAuto("Без разрешения на VPN подключиться нельзя")
            }
        }
    }

    private fun startVpn(server: Server) {
        lastStarted = server
        pendingCheck = true
        awaitingStart = true
        VpnState.update(running = false, connecting = true)
        // имя сервера превращаем в адрес до включения VPN (в фоне: сеть в главном потоке запрещена)
        val fake = useFakeIp
        thread(isDaemon = true) {
            val ip = ConfigBuilder.resolveIpv4(server.host)
            if (ip != null) AppLog.add("адрес сервера ${server.host} → $ip")
            else if (server.host.any { it.isLetter() }) AppLog.add("адрес сервера ${server.host} определить не удалось, ядро попробует само")
            runOnUiThread { launchVpnService(server, fake, ip) }
        }
    }

    private fun launchVpnService(server: Server, fakeIp: Boolean, ip: String?) {
        try {
            val cfg = ConfigBuilder.build(server, fakeIp, ip)
            val i = Intent(this, BoxVpnService::class.java)
                .setAction(BoxVpnService.ACTION_START)
                .putExtra(BoxVpnService.EXTRA_CONFIG, cfg)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Throwable) {
            pendingCheck = false
            awaitingStart = false
            AppLog.add("Не удалось запустить VPN: ${e.message ?: e}")
            endAuto(null)
            VpnState.update(running = false, connecting = false, error = e.message ?: e.toString())
        }
    }

    private fun stopVpn() {
        try {
            startService(Intent(this, BoxVpnService::class.java).setAction(BoxVpnService.ACTION_STOP))
        } catch (_: Throwable) {
        }
    }

    /** Вызывается при любом изменении состояния VPN или ядра замера (в главном потоке). */
    private fun onVpnState() {
        refreshUi()

        if (probeStarting) {
            if (VpnState.probeReady) {
                probeStarting = false
                startProbeTests()
            } else {
                val err = VpnState.probeError
                if (err != null) {
                    probeStarting = false
                    onProbeCoreError(err)
                }
            }
            return
        }

        if (VpnState.running) {
            awaitingStart = false
            if (pendingCheck) {
                pendingCheck = false
                runCheck()
            }
        } else if (!VpnState.connecting) {
            pendingCheck = false
            checkToken++ // результаты старых проверок больше не нужны
            checkText = null
            checkOk = null
            if (afterProbeStop) {
                handler.postDelayed({ proceedAfterProbe() }, 1000)
            } else if (nextAfterStop) {
                nextAfterStop = false
                handler.postDelayed({ tryNext() }, 1000)
            } else if (awaitingStart) {
                awaitingStart = false
                val err = VpnState.lastError
                val srv = lastStarted
                if (useFakeIp && srv != null && err != null && err.contains("fakeip", ignoreCase = true)) {
                    useFakeIp = false
                    AppLog.add("Ядро не приняло FakeIP, пробую обычный DNS")
                    handler.postDelayed({ startVpn(srv) }, 800)
                } else if (autoMode) {
                    // сервер не запустился (например, неверные настройки): идём к следующему
                    AppLog.add("Сервер не запустился: ${VpnState.lastError}")
                    handler.postDelayed({ tryNext() }, 500)
                }
            }
        }
    }

    // ---------- проверка интернета через VPN ----------

    private class Leg {
        @Volatile var ms = -1L
        @Volatile var err: String? = null
        fun text(): String = if (ms >= 0) "ок $ms мс" else (err ?: "нет ответа")
    }

    private fun errText(e: Throwable): String =
        e.javaClass.simpleName + (e.message?.let { ": " + it.take(80) } ?: "")

    private fun runCheck() {
        val token = ++checkToken
        checkText = "Проверяю интернет…"
        checkOk = null
        refreshUi()
        thread(isDaemon = true) {
            // Приложение исключено из туннеля, поэтому проверяем через локальный вход ядра VPN
            // (127.0.0.1:CHECK_PORT): запрос идёт ровно тем маршрутом и тем сервером, что и VPN.
            try {
                Thread.sleep(1200)
            } catch (_: InterruptedException) {
            }
            val ip = Leg()
            val https = Leg()
            val workers = ArrayList<Thread>()

            // 1) HTTPS по IP-адресу, без DNS
            workers.add(thread(isDaemon = true) { viaCore("https://1.1.1.1/cdn-cgi/trace", ip) })
            // 2) настоящий HTTPS-запрос к сайту по имени (имя разрешает сам сервер)
            workers.add(thread(isDaemon = true) { viaCore(RealProbe.CHECK_URL, https) })

            val deadline = System.currentTimeMillis() + 15000
            for (w in workers) {
                val left = deadline - System.currentTimeMillis()
                if (left > 0) w.join(left)
            }
            val detail = "по IP 1.1.1.1: ${ip.text()}; по имени cp.cloudflare.com: ${https.text()}"
            AppLog.add("Проверка интернета: $detail")
            runOnUiThread { onCheckResult(token, https.ms, detail) }
        }
    }

    /** Один HTTPS-запрос через локальный вход ядра VPN. */
    private fun viaCore(url: String, leg: Leg) {
        val t0 = System.nanoTime()
        try {
            val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", ConfigBuilder.CHECK_PORT))
            val c = URL(url).openConnection(proxy) as HttpURLConnection
            c.connectTimeout = 12000
            c.readTimeout = 12000
            c.instanceFollowRedirects = false
            c.useCaches = false
            val code = c.responseCode
            c.disconnect()
            if (code in 200..399) leg.ms = (System.nanoTime() - t0) / 1_000_000
            else leg.err = "код $code"
        } catch (e: Throwable) {
            leg.err = errText(e)
        }
    }

    private fun onCheckResult(token: Int, ms: Long, detail: String) {
        if (token != checkToken || !VpnState.running) return
        if (ms >= 0) {
            checkOk = true
            checkText = "Сервер пропускает трафик ($ms мс). Откройте браузер или Telegram, чтобы убедиться."
            if (autoMode) endAuto("Готово: этот сервер пропускает трафик.") else refreshUi()
        } else if (autoMode) {
            checkOk = false
            checkText = "Интернета через этот сервер нет"
            refreshUi()
            nextAfterStop = true
            stopVpn()
        } else {
            checkOk = false
            checkText = "Подключено, но проверка не прошла.\n$detail"
            refreshUi()
        }
    }

    // ---------- обновление списка ----------

    private fun onUpdateClick() {
        if (busy()) {
            Toast.makeText(this, "Сначала дождитесь конца замера", Toast.LENGTH_SHORT).show()
            return
        }
        if (listBusy) return
        refreshList(true)
    }

    private fun clock(ms: Long) = java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ms))

    /** Скачивает свежие списки в фоне. manual — нажали кнопку (тогда об ошибке говорим окном). */
    private fun refreshList(manual: Boolean) {
        if (listBusy || busy()) return
        listBusy = true
        prefs.edit().putLong("list_try", System.currentTimeMillis()).apply()
        note = "Обновляю список серверов…"
        refreshUi()
        val proxyPort = if (VpnState.running) ConfigBuilder.CHECK_PORT else null
        thread(isDaemon = true) {
            var dl: Downloaded? = null
            var parsed: Pair<List<Server>, Int>? = null
            try {
                dl = ListStore.download(proxyPort, { AppLog.add(it) })
                if (dl != null) parsed = ServerParser.parseAll(dl.lines)
            } catch (e: Throwable) {
                AppLog.add("Обновление списка: ${e.javaClass.simpleName}: ${e.message ?: ""}")
            }
            runOnUiThread { onListDownloaded(dl, parsed, manual) }
        }
    }

    private fun onListDownloaded(dl: Downloaded?, parsed: Pair<List<Server>, Int>?, manual: Boolean) {
        listBusy = false
        if (dl == null || parsed == null || parsed.first.size < 5) {
            note = null
            AppLog.add("Список не обновлён, остаётся прежний (${servers.size} серверов)")
            refreshUi()
            if (manual) {
                showListMenu(
                    "Не удалось скачать свежие списки: нет доступа к GitHub и его зеркалам с вашей сети. " +
                        "Можно добавить свои ссылки: скопируйте их (vless://…, trojan://… или адрес подписки) и выберите " +
                        "«Добавить из буфера обмена»."
                )
            }
            return
        }
        val now = System.currentTimeMillis()
        try {
            ListStore.save(this, dl.lines)
        } catch (e: Throwable) {
            AppLog.add("Не удалось сохранить список: ${e.message ?: e}")
        }
        listNote = "обновлён ${clock(now)}"
        prefs.edit().putLong("list_time", now).putString("list_note", listNote).apply()
        if (busy() || VpnState.connecting) {
            // пока качали, начался замер или подключение: новый список подхватится при следующем запуске
            note = null
            refreshUi()
            return
        }
        applyServers(ServerParser.parseAll(ListStore.load(this)))
        val bl = servers.count { tagOf(it) == "BL" }
        val cidr = servers.count { tagOf(it) == "CIDR" }
        note = "Список обновлён: ${servers.size} серверов (BL $bl, CIDR $cidr)." +
            if (cidr < 8) " CIDR-серверов в источнике сейчас почти не осталось: это не ошибка приложения." else ""
        AppLog.add("Список обновлён: ${servers.size} серверов, BL $bl, CIDR $cidr, не поддерживаются ${parsed.second}")
        refreshUi()
    }

    private fun applyServers(parsed: Pair<List<Server>, Int>) {
        servers = parsed.first
        skipped = parsed.second
        val keys = servers.map { it.key }.toHashSet()
        stats.keys.retainAll(keys)
        if (selectedKey == null || selectedKey !in keys) {
            selectedKey = servers.firstOrNull()?.key
            prefs.edit().putString("selected", selectedKey).apply()
        }
        rebuildRows()
    }

    /** Меню списка: свои ссылки из буфера обмена и возврат к встроенному списку. */
    private fun showListMenu(message: String?) {
        val items = arrayOf("Добавить из буфера обмена", "Скачать свежие списки", "Вернуть встроенный список")
        val b = android.app.AlertDialog.Builder(this).setTitle("Список серверов")
        if (message != null) b.setMessage(message)
        b.setItems(items) { _, which ->
            when (which) {
                0 -> importClipboard()
                1 -> onUpdateClick()
                2 -> {
                    if (busy()) return@setItems
                    ListStore.reset(this)
                    prefs.edit().remove("list_time").remove("list_note").apply()
                    listNote = "встроенный список"
                    applyServers(ServerParser.parseAll(ListStore.load(this)))
                    note = "Возвращён встроенный список: ${servers.size} серверов."
                    refreshUi()
                }
            }
        }
        b.setNegativeButton("Закрыть", null)
        b.show()
    }

    /** Берёт из буфера обмена ссылки на серверы или адрес подписки и добавляет к списку. */
    private fun importClipboard() {
        if (busy() || listBusy) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val text = try {
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        } catch (_: Throwable) {
            ""
        }.trim()
        if (text.isEmpty()) {
            Toast.makeText(this, "Буфер обмена пуст", Toast.LENGTH_LONG).show()
            return
        }
        val isUrl = (text.startsWith("http://") || text.startsWith("https://")) && !text.contains('\n') && !text.contains(' ')
        val direct = ListStore.extractLinks(text)
        if (!isUrl && direct.isEmpty()) {
            Toast.makeText(this, "В буфере нет ссылок vless:// trojan:// vmess:// ss:// hysteria2://", Toast.LENGTH_LONG).show()
            return
        }
        listBusy = true
        note = if (isUrl) "Скачиваю подписку…" else "Добавляю ссылки…"
        refreshUi()
        val proxyPort = if (VpnState.running) ConfigBuilder.CHECK_PORT else null
        thread(isDaemon = true) {
            var links = direct
            var err: String? = null
            if (isUrl) {
                try {
                    links = ListStore.extractLinks(ListStore.fetch(text, proxyPort))
                    if (links.isEmpty()) err = "По этому адресу нет ссылок на серверы"
                } catch (e: Throwable) {
                    err = "Не удалось скачать подписку: ${e.javaClass.simpleName} ${(e.message ?: "").take(60)}"
                }
            }
            val added = if (err == null) try {
                ListStore.addCustom(this, links)
            } catch (e: Throwable) {
                err = "Не удалось сохранить: ${e.message ?: e}"
                0
            } else 0
            runOnUiThread {
                listBusy = false
                if (err != null) {
                    note = err
                    AppLog.add(err)
                } else if (busy() || VpnState.connecting) {
                    note = null // сохранено, в списке появится после замера или при следующем запуске
                    AppLog.add("Из буфера обмена: ссылок ${links.size}, новых $added (применятся позже)")
                } else {
                    applyServers(ServerParser.parseAll(ListStore.load(this)))
                    note = "Добавлено своих серверов: $added (в списке теперь ${servers.size})."
                    AppLog.add("Из буфера обмена: ссылок ${links.size}, новых $added")
                }
                refreshUi()
            }
        }
    }

    // ---------- список ----------

    private fun mask(h: String): String {
        val p = h.split('.')
        return if (p.size == 4 && p.all { it.toIntOrNull() != null }) "${p[0]}.${p[1].take(1)}****.${p[3]}"
        else if (h.length > 10) h.take(3) + "****" + h.takeLast(6) else h
    }

    private fun details(s: Server): String {
        val ob = s.outbound
        val tr = if (s.protocol == "hysteria2") "udp" else (ob.optJSONObject("transport")?.optString("type")?.ifEmpty { null } ?: "tcp")
        val tls = ob.optJSONObject("tls")
        val sec = when {
            tls?.optJSONObject("reality")?.optBoolean("enabled", false) == true -> "reality"
            tls?.optBoolean("enabled", false) == true -> "tls"
            else -> ""
        }
        return mask(s.host) + " · " + tr + (if (sec.isNotEmpty()) " · $sec" else "") +
            (if (s.insecure) " · ⚠" else "")
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int) = rows[position]
        override fun getItemId(position: Int) = position.toLong()

        private inner class Holder(
            val card: LinearLayout,
            val badge: FrameLayout,
            val badgeText: TextView,
            val name: TextView,
            val addr: TextView,
            val ping: TextView,
        )

        private fun create(): View {
            val outer = FrameLayout(this@MainActivity).apply { setPadding(dp(10), dp(4), dp(10), dp(4)) }
            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val badge = FrameLayout(this@MainActivity)
            val badgeText = TextView(this@MainActivity).apply {
                textSize = 13f
                setTypeface(null, Typeface.BOLD)
                gravity = Gravity.CENTER
                rotation = 270f
            }
            badge.addView(badgeText, FrameLayout.LayoutParams(dp(64), dp(40), Gravity.CENTER))
            card.addView(badge, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT).apply {
                setMargins(dp(4), dp(4), dp(8), dp(4))
            })

            val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            val name = TextView(this@MainActivity).apply {
                textSize = 16f
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val row2 = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, 0)
            }
            val addr = TextView(this@MainActivity).apply {
                textSize = 13f
                setTextColor(GRAY)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val ping = TextView(this@MainActivity).apply {
                textSize = 12f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.BLACK)
                setPadding(dp(10), dp(3), dp(10), dp(3))
            }
            row2.addView(addr, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row2.addView(ping)
            col.addView(name)
            col.addView(row2)
            card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(0, 0, dp(10), 0)
            })

            outer.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72)))
            outer.tag = Holder(card, badge, badgeText, name, addr, ping)
            return outer
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: create()
            val h = v.tag as Holder
            val s = rows[position]
            val sel = s.key == selectedKey

            h.card.background = shape(if (sel) CARD_SEL else CARD, 16)
            h.badge.background = shape(if (sel) ACCENT else Color.rgb(58, 58, 60), 12)
            h.badgeText.setTextColor(if (sel) Color.BLACK else Color.WHITE)
            h.badgeText.text = if (s.protocol == "hysteria2") "HY2" else s.protocol.uppercase()
            h.name.text = s.name
            h.addr.text = details(s)

            val st = stats[s.key]
            val avg = st?.avg()
            when {
                avg != null -> {
                    h.ping.visibility = View.VISIBLE
                    h.ping.text = "$avg мс"
                    h.ping.background = shape(
                        when {
                            avg < 400 -> Color.rgb(120, 220, 140)
                            avg < 1000 -> Color.rgb(255, 214, 102)
                            else -> Color.rgb(255, 170, 60)
                        }, 8
                    )
                }
                st != null -> {
                    h.ping.visibility = View.VISIBLE
                    h.ping.text = st.reason ?: "Тайм-аут"
                    h.ping.background = shape(Color.rgb(255, 107, 107), 8)
                }
                else -> h.ping.visibility = View.GONE
            }
            return v
        }
    }

    companion object {
        private const val REQ_VPN = 100
        private const val PROBE_PORT = 31000
        private const val PROBE_TOTAL_MS = 60_000L
        private val FILTERS = arrayOf("Все", "BL", "CIDR")

        private val BG = Color.BLACK
        private val CARD = Color.rgb(28, 28, 30)
        private val CARD_SEL = Color.rgb(38, 78, 84)
        private val PANEL = Color.rgb(58, 58, 60)
        private val ACCENT = Color.rgb(111, 227, 240)
        private val GRAY = Color.rgb(150, 150, 156)
    }
}
