package com.vpnbest.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong

class MainActivity : Activity() {

    private lateinit var servers: List<Server>
    private var skipped = 0
    private var rows: List<Server> = emptyList()
    private val pings = HashMap<String, Int?>() // endpoint -> средний пинг
    private var selectedKey: String? = null
    private var search: BestSearch? = null
    private var pendingServer: Server? = null

    // автоподбор: после замера по очереди пробуем лучшие серверы, пока не найдём тот, через который идёт интернет
    private val handler = Handler(Looper.getMainLooper())
    private var autoMode = false
    private var autoQueue = ArrayDeque<Server>()
    private var autoTotal = 0
    private var awaitingStart = false
    private var pendingCheck = false
    private var nextAfterStop = false
    private var checkToken = 0
    private var checkText: String? = null
    private var checkOk: Boolean? = null
    private var note: String? = null

    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var btnBest: Button
    private lateinit var btnConnect: Button
    private lateinit var adapter: Adapter

    private val prefs by lazy { getSharedPreferences("vpnbest", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)

        val lines = assets.open("servers.txt").bufferedReader().readLines()
        val parsed = ServerParser.parseAll(lines)
        servers = parsed.first
        skipped = parsed.second
        rows = servers
        selectedKey = prefs.getString("selected", null)?.takeIf { k -> servers.any { it.key == k } }
            ?: servers.firstOrNull()?.key

        buildUi()
        refreshUi()

        VpnState.listener = { onVpnState() }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        // если в прошлый раз приложение упало, покажем причину (только когда VPN не работает)
        if (!VpnState.running && !VpnState.connecting) {
            CrashLog.read(this)?.let { showCrash(it) }
        }
    }

    private fun showCrash(msg: String) {
        val tv = TextView(this).apply {
            text = msg
            textSize = 11f
            setTextColor(Color.BLACK)
            setTextIsSelectable(true)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val scroll = android.widget.ScrollView(this).apply { addView(tv) }
        android.app.AlertDialog.Builder(this)
            .setTitle("В прошлый раз приложение упало")
            .setView(scroll)
            .setPositiveButton("Скопировать") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", msg))
                Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    override fun onDestroy() {
        VpnState.listener = null
        handler.removeCallbacksAndMessages(null)
        search?.cancel()
        super.onDestroy()
    }

    // ---------- интерфейс ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(8))
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "VPN Best"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.BLACK)
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)

        btnBest = Button(this).apply {
            setOnClickListener { onBestClick() }
        }
        root.addView(btnBest, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        btnConnect = Button(this).apply {
            setOnClickListener { onConnectClick() }
        }
        root.addView(btnConnect, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        info = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(6), 0, dp(6))
        }
        root.addView(info)

        adapter = Adapter()
        val list = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            divider = null
            setOnItemClickListener { _, _, pos, _ ->
                if (search != null || autoMode) return@setOnItemClickListener
                val s = rows[pos]
                selectedKey = s.key
                note = null
                prefs.edit().putString("selected", s.key).apply()
                refreshUi()
            }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun selected(): Server? = servers.find { it.key == selectedKey }

    private fun refreshUi() {
        val sel = selected()
        val searching = search != null
        val base = when {
            VpnState.connecting -> "Подключаюсь…"
            VpnState.running -> "Подключено: ${sel?.name ?: ""}"
            VpnState.lastError != null -> "Ошибка: ${VpnState.lastError}"
            else -> "Не подключено"
        }
        val check = checkText
        status.text = if (VpnState.running && check != null) "$base\n$check" else base
        status.setTextColor(
            when {
                VpnState.running && checkOk == false -> Color.rgb(200, 100, 0)
                VpnState.running -> Color.rgb(0, 130, 60)
                VpnState.lastError != null -> Color.rgb(190, 0, 0)
                else -> Color.DKGRAY
            }
        )
        btnBest.text = when {
            searching -> "Отмена замера"
            autoMode -> "Отмена проверки"
            else -> "⚡ Лучший сервер (замер 5 минут)"
        }
        btnConnect.isEnabled = !searching && !autoMode && !VpnState.connecting && sel != null
        btnConnect.text = if (VpnState.running) "Отключить" else "Подключить: ${sel?.name ?: "—"}"
        if (!searching) {
            info.text = note ?: ("Серверов: ${servers.size}" +
                (if (skipped > 0) " (ещё $skipped не поддерживаются: транспорт xhttp)" else "") +
                ". Нажмите на сервер, чтобы выбрать его.")
        }
        adapter.notifyDataSetChanged()
    }

    private fun keepScreenOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- замер пинга ----------

    private fun onBestClick() {
        if (autoMode) {
            endAuto("Проверка отменена")
            if (VpnState.running || VpnState.connecting) stopVpn()
            return
        }
        val running = search
        if (running != null) {
            running.cancel()
            return
        }
        pings.clear()
        note = null
        checkText = null
        checkOk = null
        keepScreenOn(true)
        // во время замера VPN должен быть выключен, иначе пинг покажет не реальную сеть
        var delay = 0L
        if (VpnState.running || VpnState.connecting) {
            stopVpn()
            delay = 2500L
        }
        val s = BestSearch(
            servers = servers,
            durationMs = 5 * 60 * 1000L,
            onProgress = { round, remaining, stats -> runOnUiThread { onProgress(round, remaining, stats) } },
            onDone = { ranked, stats, cancelled -> runOnUiThread { onDone(ranked, stats, cancelled) } },
        )
        search = s
        refreshUi()
        handler.postDelayed({ s.start() }, delay)
    }

    private fun onProgress(round: Int, remainingMs: Long, stats: Map<String, Stat>) {
        if (search == null) return
        applyStats(stats)
        val sec = remainingMs / 1000
        val best = rows.firstOrNull { pings[BestSearch.endpoint(it)] != null }
        info.text = "Замер: осталось %d:%02d · раунд %d".format(sec / 60, sec % 60, round) +
            (best?.let { "\nСейчас лучший: ${pings[BestSearch.endpoint(it)]} мс — ${it.name}" } ?: "")
    }

    private fun applyStats(stats: Map<String, Stat>) {
        for ((ep, st) in stats) pings[ep] = st.avg()
        rows = servers.sortedWith(compareBy<Server> { pings[BestSearch.endpoint(it)] ?: Int.MAX_VALUE })
        adapter.notifyDataSetChanged()
    }

    private fun onDone(ranked: List<Server>, stats: Map<String, Stat>, cancelled: Boolean) {
        search = null
        applyStats(stats)
        if (cancelled) {
            keepScreenOn(false)
            note = "Замер отменён"
            refreshUi()
            return
        }
        if (ranked.isEmpty()) {
            keepScreenOn(false)
            Toast.makeText(this, "Ни один сервер не ответил", Toast.LENGTH_LONG).show()
            note = "Ни один сервер не ответил на пинг"
            refreshUi()
            return
        }
        // пинг показывает лишь то, что порт открыт. Теперь проверяем, что через сервер реально идёт интернет:
        // подключаемся к лучшему, и если интернета нет, переходим к следующему.
        autoQueue = ArrayDeque(ranked)
        autoTotal = ranked.size
        autoMode = true
        tryNext()
    }

    // ---------- автоподбор рабочего сервера ----------

    private fun tryNext() {
        if (!autoMode) return
        val s = autoQueue.removeFirstOrNull()
        if (s == null) {
            endAuto("Ни один из ${autoTotal} лучших серверов не пропускает трафик. Попробуйте замер позже или выберите сервер вручную.")
            return
        }
        val n = autoTotal - autoQueue.size
        selectedKey = s.key
        prefs.edit().putString("selected", s.key).apply()
        note = "Проверяю сервер $n из $autoTotal: ${s.name}"
        checkText = null
        checkOk = null
        refreshUi()
        connect(s)
    }

    private fun endAuto(msg: String?) {
        autoMode = false
        autoQueue.clear()
        nextAfterStop = false
        keepScreenOn(false)
        if (msg != null) note = msg
        refreshUi()
    }

    // ---------- подключение ----------

    private fun onConnectClick() {
        if (VpnState.running) {
            stopVpn()
            return
        }
        note = null
        selected()?.let { connect(it) }
    }

    private fun connect(server: Server) {
        val prep = VpnService.prepare(this)
        if (prep != null) {
            pendingServer = server
            startActivityForResult(prep, REQ_VPN)
        } else {
            startVpn(server)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            val s = pendingServer
            pendingServer = null
            if (resultCode == RESULT_OK && s != null) {
                startVpn(s)
            } else {
                Toast.makeText(this, "Нужно разрешение на VPN", Toast.LENGTH_LONG).show()
                endAuto("Без разрешения на VPN подключиться нельзя")
            }
        }
    }

    private fun startVpn(server: Server) {
        try {
            val cfg = ConfigBuilder.build(server)
            val i = Intent(this, BoxVpnService::class.java)
                .setAction(BoxVpnService.ACTION_START)
                .putExtra(BoxVpnService.EXTRA_CONFIG, cfg)
            pendingCheck = true
            awaitingStart = true
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            VpnState.update(running = false, connecting = true)
        } catch (e: Throwable) {
            pendingCheck = false
            awaitingStart = false
            endAuto(null)
            VpnState.update(running = false, connecting = false, error = e.message ?: e.toString())
        }
    }

    private fun stopVpn() {
        try {
            startService(Intent(this, BoxVpnService::class.java).setAction(BoxVpnService.ACTION_STOP))
        } catch (_: Throwable) {
        }
    }

    /** Вызывается при любом изменении состояния VPN (в главном потоке). */
    private fun onVpnState() {
        refreshUi()
        if (VpnState.running) {
            awaitingStart = false
            if (pendingCheck) {
                pendingCheck = false
                runCheck()
            }
        } else if (!VpnState.connecting) {
            pendingCheck = false
            checkToken++ // результаты старых проверок больше не нужны
            checkText = null
            checkOk = null
            if (nextAfterStop) {
                nextAfterStop = false
                handler.postDelayed({ tryNext() }, 1000)
            } else if (awaitingStart) {
                awaitingStart = false
                if (autoMode) {
                    // сервер не запустился (например, неверные настройки): идём к следующему
                    handler.postDelayed({ tryNext() }, 500)
                }
            }
        }
    }

    // ---------- проверка интернета через VPN ----------

    private fun runCheck() {
        val token = ++checkToken
        checkText = "Проверяю интернет…"
        checkOk = null
        refreshUi()
        Thread {
            waitForVpnNetwork()
            val result = AtomicLong(-1)
            val worker = Thread {
                try {
                    val t0 = System.nanoTime()
                    val c = URL(CHECK_URL).openConnection() as HttpURLConnection
                    c.connectTimeout = 8000
                    c.readTimeout = 8000
                    c.instanceFollowRedirects = false
                    c.useCaches = false
                    val code = c.responseCode
                    c.disconnect()
                    if (code == 204) result.set((System.nanoTime() - t0) / 1_000_000)
                } catch (_: Throwable) {
                }
            }
            worker.isDaemon = true
            worker.start()
            worker.join(12000) // DNS может зависнуть дольше таймаутов соединения
            val ms = result.get()
            runOnUiThread { onCheckResult(token, ms) }
        }.apply { isDaemon = true }.start()
    }

    /** Ждём, пока Android переключит приложение на VPN: иначе проверка пойдёт мимо туннеля и соврёт. */
    private fun waitForVpnNetwork() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var waited = 0
            while (waited < 6000) {
                val n = cm.activeNetwork
                val caps = if (n != null) cm.getNetworkCapabilities(n) else null
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) break
                Thread.sleep(300)
                waited += 300
            }
            Thread.sleep(700)
        } catch (_: Throwable) {
        }
    }

    private fun onCheckResult(token: Int, ms: Long) {
        if (token != checkToken || !VpnState.running) return
        if (ms >= 0) {
            checkOk = true
            checkText = "Интернет работает ($ms мс)"
            if (autoMode) endAuto("Готово: этот сервер пропускает трафик.") else refreshUi()
        } else if (autoMode) {
            checkOk = false
            checkText = "Интернета через этот сервер нет"
            refreshUi()
            nextAfterStop = true
            stopVpn()
        } else {
            checkOk = false
            checkText = "Подключено, но интернета нет: сервер не пропускает трафик. Выберите другой."
            refreshUi()
        }
    }

    // ---------- список ----------

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int) = rows[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val s = rows[position]
            val box = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                addView(TextView(context).apply { textSize = 15f; setTextColor(Color.BLACK) })
                addView(TextView(context).apply { textSize = 12f; setTextColor(Color.GRAY) })
            }
            val title = box.getChildAt(0) as TextView
            val sub = box.getChildAt(1) as TextView
            val ep = BestSearch.endpoint(s)
            val pingText = when {
                !s.tcp -> "UDP"
                pings[ep] != null -> "${pings[ep]} мс"
                else -> "—"
            }
            title.text = "$pingText   ${s.name}"
            sub.text = "${s.protocol.uppercase()} · $ep" + if (s.insecure) " · ⚠ без проверки сертификата" else ""
            box.setBackgroundColor(if (s.key == selectedKey) Color.rgb(220, 238, 255) else Color.TRANSPARENT)
            box.gravity = Gravity.CENTER_VERTICAL
            return box
        }
    }

    companion object {
        private const val REQ_VPN = 100
        private const val CHECK_URL = "https://cp.cloudflare.com/generate_204"
    }
}
