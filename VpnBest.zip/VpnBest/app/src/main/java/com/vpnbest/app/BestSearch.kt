package com.vpnbest.app

import android.os.SystemClock
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Статистика пинга для одного адреса host:port. */
class Stat {
    var ok = 0
        private set
    var total = 0
        private set
    private var sum = 0L

    @Synchronized
    fun record(ms: Int?) {
        total++
        if (ms != null) {
            ok++
            sum += ms
        }
    }

    @Synchronized
    fun avg(): Int? = if (ok == 0) null else (sum / ok).toInt()

    @Synchronized
    fun loss(): Double = if (total == 0) 1.0 else 1.0 - ok.toDouble() / total

    /** Чем меньше, тем лучше: средний пинг плюс штраф за потери. */
    @Synchronized
    fun score(): Double? {
        val a = avg() ?: return null
        return a + loss() * 400.0
    }
}

/**
 * Замер пинга всех серверов в течение [durationMs]: повторяет раунды TCP-подключений,
 * затем выбирает сервер с лучшим результатом (средний пинг + штраф за потери).
 */
class BestSearch(
    private val servers: List<Server>,
    private val durationMs: Long,
    private val onProgress: (round: Int, remainingMs: Long, stats: Map<String, Stat>) -> Unit,
    private val onDone: (best: Server?, stats: Map<String, Stat>, cancelled: Boolean) -> Unit,
) {
    @Volatile
    private var cancelled = false
    private val stats = ConcurrentHashMap<String, Stat>()

    fun cancel() {
        cancelled = true
    }

    fun start() {
        Thread { runSearch() }.apply { isDaemon = true }.start()
    }

    private fun runSearch() {
        val targets = servers.filter { it.tcp }
        val endpoints = targets.groupBy { endpoint(it) }
        for (ep in endpoints.keys) stats[ep] = Stat()

        val pool = Executors.newFixedThreadPool(48)
        val resolved = ConcurrentHashMap<String, InetAddress>()
        val end = SystemClock.elapsedRealtime() + durationMs
        var round = 0

        while (!cancelled && SystemClock.elapsedRealtime() < end) {
            round++
            val latch = CountDownLatch(endpoints.size)
            for ((ep, list) in endpoints) {
                val s = list[0]
                pool.execute {
                    try {
                        stats[ep]!!.record(tcpPing(s.host, s.port, resolved))
                    } catch (_: Throwable) {
                    } finally {
                        latch.countDown()
                    }
                }
            }
            while (!latch.await(500, TimeUnit.MILLISECONDS)) {
                if (cancelled || SystemClock.elapsedRealtime() >= end) break
                onProgress(round, end - SystemClock.elapsedRealtime(), stats)
            }
            onProgress(round, maxOf(0, end - SystemClock.elapsedRealtime()), stats)

            // небольшая пауза между раундами, чтобы не долбить серверы без остановки
            var pause = 0
            while (pause < 1500 && !cancelled && SystemClock.elapsedRealtime() < end) {
                Thread.sleep(250)
                pause += 250
            }
        }
        pool.shutdownNow()

        val best = if (cancelled) null else pickBest(targets)
        onDone(best, stats, cancelled)
    }

    private fun pickBest(targets: List<Server>): Server? {
        var best: Server? = null
        var bestScore = Double.MAX_VALUE
        for (s in targets) {
            val st = stats[endpoint(s)] ?: continue
            // сервер, который отвечает хуже чем в половине попыток, не берём
            if (st.total >= 3 && st.loss() > 0.5) continue
            val sc = st.score() ?: continue
            if (sc < bestScore) {
                bestScore = sc
                best = s
            }
        }
        return best
    }

    private fun tcpPing(host: String, port: Int, cache: ConcurrentHashMap<String, InetAddress>): Int? {
        return try {
            val addr = cache[host] ?: InetAddress.getByName(host).also { cache[host] = it }
            val t0 = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(addr, port), 3000) }
            ((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1)
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        fun endpoint(s: Server) = "${s.host}:${s.port}"
    }
}
