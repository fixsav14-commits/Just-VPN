package com.vpnbest.app

import org.json.JSONArray
import org.json.JSONObject

/** Собирает конфиг sing-box (формат 1.11) для выбранного сервера. */
object ConfigBuilder {

    fun build(server: Server): String {
        val dns = JSONObject()
            .put(
                "servers", JSONArray()
                    // основной DNS: через прокси
                    .put(
                        JSONObject().put("tag", "remote")
                            .put("address", "https://1.1.1.1/dns-query")
                            .put("detour", "proxy")
                    )
                    // для определения IP самого сервера: напрямую (без detour: "detour" на пустой
                    // direct-outbound ядро считает ошибкой, а обычный сокет и так идёт мимо туннеля)
                    .put(
                        JSONObject().put("tag", "bootstrap")
                            .put("address", "77.88.8.8")
                    )
            )
            .put("rules", JSONArray().put(JSONObject().put("outbound", "any").put("server", "bootstrap")))
            .put("final", "remote")
            .put("strategy", "ipv4_only")

        val tun = JSONObject()
            .put("type", "tun").put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
            .put("mtu", 9000)
            .put("auto_route", true)
            .put("stack", "gvisor")

        val route = JSONObject()
            .put("auto_detect_interface", true)
            .put("final", "proxy")
            .put(
                "rules", JSONArray()
                    .put(JSONObject().put("action", "sniff"))
                    .put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
                    .put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))
            )

        val root = JSONObject()
            .put("log", JSONObject().put("level", "info"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(tun))
            .put(
                "outbounds", JSONArray()
                    .put(server.outbound)
                    .put(JSONObject().put("type", "direct").put("tag", "direct"))
            )
            .put("route", route)
        return root.toString()
    }

    /**
     * Конфиг для замера: без туннеля. На каждый сервер свой локальный HTTP-прокси (порт basePort + i),
     * который ведёт строго в этот сервер. Так можно сделать настоящий запрос через каждый из них.
     */
    fun buildProbe(servers: List<Server>, basePort: Int): String {
        val inbounds = JSONArray()
        val outbounds = JSONArray()
        val rules = JSONArray()
        for ((i, s) in servers.withIndex()) {
            inbounds.put(
                JSONObject().put("type", "mixed").put("tag", "in-$i")
                    .put("listen", "127.0.0.1").put("listen_port", basePort + i)
            )
            outbounds.put(JSONObject(s.outbound.toString()).put("tag", "out-$i"))
            rules.put(JSONObject().put("inbound", JSONArray().put("in-$i")).put("outbound", "out-$i"))
        }
        outbounds.put(JSONObject().put("type", "direct").put("tag", "direct"))

        val dns = JSONObject()
            .put("servers", JSONArray().put(JSONObject().put("tag", "bootstrap").put("address", "77.88.8.8")))
            .put("strategy", "ipv4_only")

        val root = JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", inbounds)
            .put("outbounds", outbounds)
            .put("route", JSONObject().put("rules", rules).put("final", "direct"))
        return root.toString()
    }
}
