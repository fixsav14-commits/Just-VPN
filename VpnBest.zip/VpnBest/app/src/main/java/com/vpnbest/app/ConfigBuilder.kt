package com.vpnbest.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetAddress

/** Собирает конфиг sing-box (формат 1.11) для выбранного сервера. */
object ConfigBuilder {

    /** Локальный HTTP/SOCKS-вход ядра VPN: приложение проверяет через него, работает ли сервер. */
    const val CHECK_PORT = 31999

    /**
     * Адрес сервера, если он задан именем: узнаём его заранее (до включения VPN) и подставляем в конфиг.
     * Тогда ядру не нужен DNS, чтобы дойти до самого сервера: в туннельном режиме именно этот запрос
     * зацикливался ("DNS query loopback in transport[bootstrap]") и сервер не открывался.
     */
    fun resolveIpv4(host: String): String? {
        if (host.isEmpty() || host.contains(':') || host.all { it.isDigit() || it == '.' }) return null
        var result: String? = null
        val t = Thread {
            try {
                result = InetAddress.getAllByName(host).firstOrNull { it is Inet4Address }?.hostAddress
            } catch (_: Throwable) {
            }
        }
        t.isDaemon = true
        t.start()
        t.join(5000)
        return result
    }

    /** Подставляет IP вместо имени сервера, а имя переносит в SNI и заголовок Host, чтобы handshake не изменился. */
    private fun pinIp(ob: JSONObject, ip: String) {
        val host = ob.optString("server")
        ob.optJSONObject("tls")?.let { tls ->
            if (tls.optString("server_name").isEmpty()) tls.put("server_name", host)
        }
        ob.optJSONObject("transport")?.let { tr ->
            when (tr.optString("type")) {
                "ws" -> {
                    val h = tr.optJSONObject("headers") ?: JSONObject().also { tr.put("headers", it) }
                    if (!h.has("Host")) h.put("Host", host)
                }
                "httpupgrade" -> if (tr.optString("host").isEmpty()) tr.put("host", host)
            }
        }
        ob.put("server", ip)
    }

    fun build(server: Server, fakeIp: Boolean = true, pinnedIp: String? = null): String {
        val dns = if (fakeIp) dnsFakeIp() else dnsRemote()

        val proxy = JSONObject(server.outbound.toString())
        if (pinnedIp != null) pinIp(proxy, pinnedIp)

        val tun = JSONObject()
            .put("type", "tun").put("tag", "tun-in")
            .put("address", JSONArray().put("172.19.0.1/30").put("fdfe:dcba:9876::1/126"))
            .put("mtu", 9000)
            .put("auto_route", true)
            .put("stack", "gvisor")
        val checkIn = JSONObject()
            .put("type", "mixed").put("tag", "check-in")
            .put("listen", "127.0.0.1").put("listen_port", CHECK_PORT)

        val route = JSONObject()
            .put("auto_detect_interface", true)
            .put("final", "proxy")
            .put(
                "rules", JSONArray()
                    .put(JSONObject().put("action", "sniff"))
                    .put(JSONObject().put("protocol", "dns").put("action", "hijack-dns"))
                    .put(JSONObject().put("ip_is_private", true).put("outbound", "direct"))
            )

        val root = JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", JSONArray().put(tun).put(checkIn))
            .put(
                // direct стоит первым: в старом формате DNS сервер без detour ходит через ПЕРВЫЙ outbound,
                // и запросы к DNS шли бы через сам прокси. Куда идёт трафик, задаёт route.final.
                "outbounds", JSONArray()
                    .put(JSONObject().put("type", "direct").put("tag", "direct"))
                    .put(proxy)
            )
            .put("route", route)
        return root.toString()
    }

    /**
     * FakeIP: приложениям отдаются «ненастоящие» адреса, а настоящее имя сайта уходит на сам прокси-сервер,
     * и тот его резолвит. Так не нужно ходить за DNS через прокси (у части серверов DoH заблокирован).
     */
    private fun dnsFakeIp(): JSONObject = JSONObject()
        .put(
            "servers", JSONArray()
                // для определения IP самого сервера: напрямую (без detour: "detour" на пустой
                // direct-outbound ядро считает ошибкой, а обычный сокет и так идёт мимо туннеля)
                .put(JSONObject().put("tag", "bootstrap").put("address", "77.88.8.8"))
                .put(JSONObject().put("tag", "fakeip").put("address", "fakeip"))
        )
        .put(
            "rules", JSONArray()
                .put(JSONObject().put("outbound", "any").put("server", "bootstrap"))
                .put(JSONObject().put("query_type", JSONArray().put("A").put("AAAA")).put("server", "fakeip"))
        )
        .put(
            "fakeip", JSONObject()
                .put("enabled", true)
                .put("inet4_range", "198.18.0.0/15")
                .put("inet6_range", "fc00::/18")
        )
        .put("final", "bootstrap")
        .put("strategy", "ipv4_only")

    /** Запасной вариант: DNS-over-HTTPS через прокси. */
    private fun dnsRemote(): JSONObject = JSONObject()
        .put(
            "servers", JSONArray()
                .put(
                    JSONObject().put("tag", "remote")
                        .put("address", "https://1.1.1.1/dns-query")
                        .put("detour", "proxy")
                )
                .put(JSONObject().put("tag", "bootstrap").put("address", "77.88.8.8"))
        )
        .put("rules", JSONArray().put(JSONObject().put("outbound", "any").put("server", "bootstrap")))
        .put("final", "remote")
        .put("strategy", "ipv4_only")

    /**
     * Конфиг для замера: без туннеля. На каждый сервер свой локальный HTTP-прокси (порт basePort + i),
     * который ведёт строго в этот сервер. Так можно сделать настоящий запрос через каждый из них.
     */
    fun buildProbe(servers: List<Server>, basePort: Int): String {
        val inbounds = JSONArray()
        // direct первым: DNS-запросы ядра не должны идти через случайный сервер из списка
        val outbounds = JSONArray().put(JSONObject().put("type", "direct").put("tag", "direct"))
        val rules = JSONArray()
        for ((i, s) in servers.withIndex()) {
            inbounds.put(
                JSONObject().put("type", "mixed").put("tag", "in-$i")
                    .put("listen", "127.0.0.1").put("listen_port", basePort + i)
            )
            outbounds.put(JSONObject(s.outbound.toString()).put("tag", "out-$i"))
            rules.put(JSONObject().put("inbound", JSONArray().put("in-$i")).put("outbound", "out-$i"))
        }

        val dns = JSONObject()
            .put("servers", JSONArray().put(JSONObject().put("tag", "bootstrap").put("address", "77.88.8.8")))
            .put("strategy", "ipv4_only")

        val root = JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", dns)
            .put("inbounds", inbounds)
            .put("outbounds", outbounds)
            .put("route", JSONObject().put("rules", rules).put("final", "direct"))
        return root.toString()
    }
}
