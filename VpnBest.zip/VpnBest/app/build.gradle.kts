plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vpnbest.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vpnbest.app"
        minSdk = 24
        // 33: на 34 для VPN-сервиса на переднем плане нужен отдельный тип службы
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    // Ядро sing-box (собирается в CI, см. .github/workflows/build.yml)
    implementation(files("libs/libbox.aar"))
}
