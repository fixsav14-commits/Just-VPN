plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vpnbest.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vpnbest.app"
        minSdk = 24
        // 33: на 34 для VPN-сервиса на переднем плане нужен отдельный тип службы
        targetSdk = 33
        // номер сборки на GitHub растёт сам: так новая версия всегда ставится поверх старой
        val build = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toIntOrNull() ?: 1
        versionCode = build
        versionName = "1.$build"
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Постоянный ключ подписи. Без него GitHub при каждой сборке создаёт новый, и обновление поверх
    // установленной версии не ставится («конфликт с существующим пакетом»): приходится удалять приложение.
    // Если файла ключа нет в репозитории, сборка идёт как раньше, с обычным отладочным ключом.
    val sharedKey = file("vpnbest.keystore")
    if (sharedKey.exists()) {
        signingConfigs {
            create("shared") {
                storeFile = sharedKey
                storePassword = "vpnbest"
                keyAlias = "vpnbest"
                keyPassword = "vpnbest"
            }
        }
    }

    buildTypes {
        debug {
            if (sharedKey.exists()) signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = false
            if (sharedKey.exists()) signingConfig = signingConfigs.getByName("shared")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    // Ядро sing-box (собирается в CI, см. .github/workflows/build.yml)
    implementation(files("libs/libbox.aar"))
}
